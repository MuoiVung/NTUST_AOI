#!/usr/bin/env python3
"""
DUO_AOI PC workflow + dual-camera pair test, v4.

This script is the PC-side workflow test client. It talks to either the real FX5U
or the included Python PLC simulator using SLMP / MC 3E binary frames, and it
uses a separate camera service during the capture window.

Mailbox map:
    PC -> PLC event: D100-D109
    PLC ACK:         D110-D111
    PLC diagnostics: D120-D127
    PLC -> PC event: D200-D209
    PC ACK:          D210-D211

Key v2 changes:
    - Robust socket receive logic for SLMP responses.
    - The PC ACKs each PLC event and waits until that exact event is gone.
      It accepts either D200=0 or D201 changing to a new PLC sequence.
    - Better diagnostics on timeout.
    - Optional startup draining of stale PLC events without directly writing D200-D209.
    - Dual-camera service integration: authorize capture only when TOP and BOTTOM are ready/fresh,
      save a paired TOP/BOTTOM capture during CAPTURE_WINDOW_OPEN, then send CAPTURE_DONE.
"""

from __future__ import annotations

import argparse
import socket
import struct
import time
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence


# ------------------------------------------------------------
# PC -> PLC events
# ------------------------------------------------------------

EVT_NONE = 0
EVT_PC_READY = 10
EVT_SET_MODE_MANUAL = 11
EVT_SET_MODE_SEMI_AUTO = 12
EVT_START_RUN = 13
EVT_STOP_RUN = 16
EVT_RESET_ERROR = 17
EVT_RECIPE_DOWNLOAD_START = 18
EVT_RECIPE_STEP_DATA = 19
EVT_RECIPE_DOWNLOAD_END = 20
EVT_CAPTURE_AUTHORIZED = 50
EVT_CAPTURE_REJECTED = 51
EVT_CAPTURE_DONE = 52


# ------------------------------------------------------------
# PLC -> PC events
# ------------------------------------------------------------

EVT_PLC_READY = 100
EVT_MODE_CHANGED = 101
EVT_RUN_STARTED = 102
EVT_RUN_STOPPED = 104
EVT_RUN_COMPLETE = 105
EVT_SEMI_STEP_STARTED = 150
EVT_POSITION_REACHED = 151
EVT_CAPTURE_AUTH_REQUEST = 152
EVT_CAPTURE_WINDOW_OPEN = 153
EVT_CAPTURE_WINDOW_CLOSED = 154
EVT_STEP_COMPLETE = 155
EVT_RECIPE_LOADED = 156
EVT_PLC_ERROR = 900

EVENT_NAMES = {
    EVT_PLC_READY: "PLC_READY",
    EVT_MODE_CHANGED: "MODE_CHANGED",
    EVT_RUN_STARTED: "RUN_STARTED",
    EVT_RUN_STOPPED: "RUN_STOPPED",
    EVT_RUN_COMPLETE: "RUN_COMPLETE",
    EVT_SEMI_STEP_STARTED: "SEMI_STEP_STARTED",
    EVT_POSITION_REACHED: "POSITION_REACHED",
    EVT_CAPTURE_AUTH_REQUEST: "CAPTURE_AUTH_REQUEST",
    EVT_CAPTURE_WINDOW_OPEN: "CAPTURE_WINDOW_OPEN",
    EVT_CAPTURE_WINDOW_CLOSED: "CAPTURE_WINDOW_CLOSED",
    EVT_STEP_COMPLETE: "STEP_COMPLETE",
    EVT_RECIPE_LOADED: "RECIPE_LOADED",
    EVT_PLC_ERROR: "PLC_ERROR",
}


# ------------------------------------------------------------
# ACK status
# ------------------------------------------------------------

ACK_OK = 0
ACK_REJECTED = 1
ACK_BUSY = 2
ACK_INVALID_STATE = 3
ACK_INVALID_PAYLOAD = 4
ACK_SAFETY_NOT_OK = 5
ACK_TIMEOUT = 6
ACK_DUPLICATE_SEQUENCE = 7
ACK_UNKNOWN_EVENT = 8

ACK_NAMES = {
    ACK_OK: "ACK_OK",
    ACK_REJECTED: "ACK_REJECTED",
    ACK_BUSY: "ACK_BUSY",
    ACK_INVALID_STATE: "ACK_INVALID_STATE",
    ACK_INVALID_PAYLOAD: "ACK_INVALID_PAYLOAD",
    ACK_SAFETY_NOT_OK: "ACK_SAFETY_NOT_OK",
    ACK_TIMEOUT: "ACK_TIMEOUT",
    ACK_DUPLICATE_SEQUENCE: "ACK_DUPLICATE_SEQUENCE",
    ACK_UNKNOWN_EVENT: "ACK_UNKNOWN_EVENT",
}


# ------------------------------------------------------------
# D register map
# ------------------------------------------------------------

D_PC_EVT = 100      # D100-D109
D_PLC_ACK = 110     # D110-D111
D_PLC_DIAG = 120    # D120-D127
D_PLC_EVT = 200     # D200-D209
D_PC_ACK = 210      # D210-D211

D_DEVICE_CODE = 0xA8


@dataclass(frozen=True)
class PlcEvent:
    event_type: int
    sequence: int
    payload: List[int]

    @property
    def name(self) -> str:
        return EVENT_NAMES.get(self.event_type, f"EVENT_{self.event_type}")


class SlmpClient:
    """Minimal SLMP / MC 3E binary client for D-register read/write."""

    def __init__(self, host: str, port: int, timeout: float = 5.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock: Optional[socket.socket] = None

    def __enter__(self) -> "SlmpClient":
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.sock is not None:
            self.sock.close()
            self.sock = None

    def _build_header(self, payload: bytes) -> bytes:
        subheader = b"\x50\x00"   # 3E binary request
        network_no = b"\x00"
        pc_no = b"\xFF"
        io_no = b"\xFF\x03"
        station_no = b"\x00"
        monitoring_timer = struct.pack("<H", 0x0010)
        request_data = monitoring_timer + payload
        request_length = struct.pack("<H", len(request_data))
        return subheader + network_no + pc_no + io_no + station_no + request_length + request_data

    def _recv_exact(self, n: int) -> bytes:
        assert self.sock is not None
        chunks: List[bytes] = []
        remaining = n
        while remaining > 0:
            chunk = self.sock.recv(remaining)
            if not chunk:
                raise RuntimeError("Socket closed while waiting for SLMP response")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def _exchange(self, frame: bytes) -> bytes:
        assert self.sock is not None
        self.sock.sendall(frame)

        header = self._recv_exact(9)
        if len(header) != 9:
            raise RuntimeError(f"Short SLMP response header: {header.hex(' ')}")
        if header[0:2] != b"\xD0\x00":
            raise RuntimeError(f"Unexpected SLMP response subheader: {header.hex(' ')}")

        response_length = struct.unpack("<H", header[7:9])[0]
        body = self._recv_exact(response_length)
        if len(body) < 2:
            raise RuntimeError(f"Short SLMP response body: {body.hex(' ')}")

        end_code = struct.unpack("<H", body[0:2])[0]
        if end_code != 0:
            raise RuntimeError(
                f"PLC returned SLMP end code 0x{end_code:04X}. "
                f"Header={header.hex(' ')} Body={body.hex(' ')}"
            )

        return body[2:]

    def read_d(self, start: int, points: int = 1) -> List[int]:
        payload = bytearray()
        payload += struct.pack("<H", 0x0401)  # batch read
        payload += struct.pack("<H", 0x0000)  # word device
        payload += start.to_bytes(3, byteorder="little", signed=False)
        payload += bytes([D_DEVICE_CODE])
        payload += struct.pack("<H", points)

        data = self._exchange(self._build_header(bytes(payload)))
        expected = 2 * points
        if len(data) < expected:
            raise RuntimeError(f"Short read response: {data.hex(' ')}")
        return list(struct.unpack("<" + "H" * points, data[:expected]))

    def write_d(self, start: int, values: Iterable[int]) -> None:
        vals = [int(v) & 0xFFFF for v in values]
        payload = bytearray()
        payload += struct.pack("<H", 0x1401)  # batch write
        payload += struct.pack("<H", 0x0000)  # word device
        payload += start.to_bytes(3, byteorder="little", signed=False)
        payload += bytes([D_DEVICE_CODE])
        payload += struct.pack("<H", len(vals))
        for value in vals:
            payload += struct.pack("<H", value)

        self._exchange(self._build_header(bytes(payload)))


class WorkflowTester:
    def __init__(
        self,
        client: SlmpClient,
        poll_interval: float = 0.05,
        timeout: float = 5.0,
        strict_clear: bool = False,
    ):
        self.client = client
        self.poll_interval = poll_interval
        self.timeout = timeout
        self.strict_clear = strict_clear
        self.pc_seq = 0

    # -------------------------------
    # Low-level helpers
    # -------------------------------

    def read_plc_event_raw(self) -> List[int]:
        return self.client.read_d(D_PLC_EVT, 10)

    def read_plc_ack_raw(self) -> List[int]:
        return self.client.read_d(D_PLC_ACK, 2)

    def read_diagnostics(self) -> List[int]:
        return self.client.read_d(D_PLC_DIAG, 8)

    def print_mailboxes(self) -> None:
        pc_evt = self.client.read_d(D_PC_EVT, 10)
        plc_ack = self.client.read_d(D_PLC_ACK, 2)
        diag = self.client.read_d(D_PLC_DIAG, 8)
        plc_evt = self.client.read_d(D_PLC_EVT, 10)
        pc_ack = self.client.read_d(D_PC_ACK, 2)
        print(f"D100-D109 PC_EVT   = {pc_evt}")
        print(f"D110-D111 PLC_ACK  = {plc_ack}")
        print(f"D120-D127 PLC_DIAG = {diag}")
        print(f"D200-D209 PLC_EVT  = {plc_evt}")
        print(f"D210-D211 PC_ACK   = {pc_ack}")

    def clear_pc_side(self) -> None:
        self.client.write_d(D_PC_EVT, [0] * 10)
        self.client.write_d(D_PC_ACK, [0, 0])

    def drain_stale_plc_events(self, max_events: int = 10) -> None:
        """ACK stale PLC events at startup without directly writing D200-D209."""
        for _ in range(max_events):
            words = self.read_plc_event_raw()
            event_type, event_seq = words[0], words[1]
            if event_type == EVT_NONE or event_seq == 0:
                return
            event = PlcEvent(event_type, event_seq, words[2:10])
            print(f"Draining stale PLC event: {event.name} ({event.event_type}) seq={event.sequence}")
            self.ack_plc_event(event.sequence)
            self.wait_plc_event_gone(event.sequence)

    # -------------------------------
    # PC -> PLC command path
    # -------------------------------

    def send_pc_event(
        self,
        event_type: int,
        payload: Optional[Sequence[int]] = None,
        expected_ack: int = ACK_OK,
    ) -> int:
        self.pc_seq = (self.pc_seq + 1) & 0xFFFF
        if self.pc_seq == 0:
            self.pc_seq = 1

        pay = list(payload or [])[:8]
        pay += [0] * (8 - len(pay))
        frame = [event_type, self.pc_seq] + pay

        print(f"PC -> PLC: event={event_type} seq={self.pc_seq} payload={pay}")
        self.client.write_d(D_PC_EVT, frame)

        deadline = time.monotonic() + self.timeout
        last_ack: List[int] | None = None
        while time.monotonic() < deadline:
            ack_seq, ack_status = self.read_plc_ack_raw()
            last_ack = [ack_seq, ack_status]
            if ack_seq == self.pc_seq:
                ack_name = ACK_NAMES.get(ack_status, f"ACK_{ack_status}")
                print(f"PLC ACK: seq={ack_seq} status={ack_status} ({ack_name})")
                if ack_status != expected_ack:
                    self.print_mailboxes()
                    raise RuntimeError(
                        f"Unexpected PLC ACK. Expected {expected_ack}, got {ack_status} ({ack_name})."
                    )
                return ack_status
            time.sleep(self.poll_interval)

        self.print_mailboxes()
        raise TimeoutError(
            f"Timed out waiting for PLC ACK for PC seq {self.pc_seq}. Last ACK={last_ack}"
        )

    # -------------------------------
    # PLC -> PC event path
    # -------------------------------

    def wait_any_plc_event(self) -> PlcEvent:
        deadline = time.monotonic() + self.timeout
        last_words: List[int] | None = None

        while time.monotonic() < deadline:
            words = self.read_plc_event_raw()
            last_words = words
            event_type, event_seq = words[0], words[1]
            payload = words[2:10]
            if event_type != EVT_NONE and event_seq != 0:
                event = PlcEvent(event_type, event_seq, payload)
                print(
                    f"PLC -> PC: {event.name} ({event.event_type}) "
                    f"seq={event.sequence} payload={event.payload}"
                )
                return event
            time.sleep(self.poll_interval)

        self.print_mailboxes()
        raise TimeoutError(f"Timed out waiting for any PLC event. Last D200-D209={last_words}")

    def wait_plc_event(self, expected_type: int) -> PlcEvent:
        event = self.wait_any_plc_event()
        if event.event_type != expected_type:
            self.ack_plc_event(event.sequence)
            self.print_mailboxes()
            raise RuntimeError(
                f"Expected PLC event {expected_type}, got {event.event_type} ({event.name})"
            )
        self.ack_and_wait_gone(event)
        return event

    def ack_plc_event(self, plc_seq: int, status: int = ACK_OK) -> None:
        print(f"PC ACK -> PLC: seq={plc_seq} status={status}")
        self.client.write_d(D_PC_ACK, [plc_seq, status])

    def ack_and_wait_gone(self, event: PlcEvent) -> None:
        self.ack_plc_event(event.sequence)
        self.wait_plc_event_gone(event.sequence)

    def wait_plc_event_gone(self, acked_sequence: int) -> None:
        """Wait until the ACKed PLC event is no longer active.

        Normal clear condition:
            D200 == 0

        Robust advancement condition:
            D201 != acked_sequence

        The second condition handles fast PLC scans where D200=0 exists only briefly
        before the next event is published.
        """
        deadline = time.monotonic() + self.timeout
        last_pair: List[int] | None = None

        while time.monotonic() < deadline:
            event_type, event_seq = self.client.read_d(D_PLC_EVT, 2)
            last_pair = [event_type, event_seq]

            if event_type == EVT_NONE:
                return

            if not self.strict_clear and event_seq != acked_sequence:
                print(
                    f"PLC mailbox advanced from seq={acked_sequence} "
                    f"to seq={event_seq}; accepting old event as cleared"
                )
                return

            time.sleep(self.poll_interval)

        self.print_mailboxes()
        raise TimeoutError(
            f"Timed out waiting for PLC event seq {acked_sequence} to clear/go away. "
            f"Last D200-D201={last_pair}"
        )



# ------------------------------------------------------------
# Dual-camera service client
# ------------------------------------------------------------

import json
from pathlib import Path


class CameraPairClient:
    """Small JSON-lines TCP client for duo_aoi_camera_pair_service.py."""

    def __init__(self, host: str, port: int, timeout: float = 5.0):
        self.host = host
        self.port = int(port)
        self.timeout = float(timeout)
        self.sock: Optional[socket.socket] = None
        self.file = None

    def __enter__(self) -> "CameraPairClient":
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        self.file = self.sock.makefile("rwb")
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.file is not None:
            self.file.close()
            self.file = None
        if self.sock is not None:
            self.sock.close()
            self.sock = None

    def request(self, cmd: str, **kwargs) -> dict:
        assert self.file is not None
        payload = {"cmd": cmd}
        payload.update(kwargs)
        line = json.dumps(payload).encode("utf-8") + b"\n"
        self.file.write(line)
        self.file.flush()
        response_line = self.file.readline()
        if not response_line:
            raise RuntimeError("Camera service closed the connection")
        response = json.loads(response_line.decode("utf-8"))
        if not response.get("ok", False):
            raise RuntimeError(f"Camera command {cmd!r} failed: {response}")
        return response

    def start(self) -> dict:
        return self.request("start_all")

    def status(self, max_age_s: float = 1.0) -> dict:
        return self.request("status", max_age_s=max_age_s)

    def fresh_pair(self, max_age_s: float = 1.0, max_pair_delta_s: float = 0.5) -> dict:
        return self.request("fresh_pair", max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)

    def wait_pair_ready_and_fresh(
        self,
        timeout: float,
        poll_interval: float = 0.05,
        max_age_s: float = 1.0,
        max_pair_delta_s: float = 0.5,
    ) -> dict:
        deadline = time.monotonic() + timeout
        last_pair = None
        while time.monotonic() < deadline:
            pair_response = self.fresh_pair(max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)
            last_pair = pair_response
            if pair_response.get("ready") and pair_response.get("fresh"):
                return pair_response
            time.sleep(poll_interval)
        raise TimeoutError(f"Camera pair was not ready/fresh before timeout. Last pair state={last_pair}")

    def save_pair(
        self,
        run_code: str,
        step_index: int,
        output_dir: str,
        max_age_s: float = 1.0,
        max_pair_delta_s: float = 0.5,
    ) -> dict:
        response = self.request(
            "save_pair",
            run_code=run_code,
            step_index=int(step_index),
            output_dir=output_dir,
            max_age_s=max_age_s,
            max_pair_delta_s=max_pair_delta_s,
        )
        return response["pair"]


class NullCameraPairClient:
    """Used when --no-camera is selected."""

    def __enter__(self) -> "NullCameraPairClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def start(self) -> dict:
        return {"ok": True, "message": "null camera pair"}

    def wait_pair_ready_and_fresh(
        self,
        timeout: float,
        poll_interval: float = 0.05,
        max_age_s: float = 1.0,
        max_pair_delta_s: float = 0.5,
    ) -> dict:
        return {"ready": True, "fresh": True, "backend": "none", "roles": ["TOP", "BOTTOM"]}

    def save_pair(
        self,
        run_code: str,
        step_index: int,
        output_dir: str,
        max_age_s: float = 1.0,
        max_pair_delta_s: float = 0.5,
    ) -> dict:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        saved = []
        for role in ("TOP", "BOTTOM"):
            path = Path(output_dir) / f"{run_code}_step_{int(step_index):04d}_{role}_no_camera.json"
            path.write_text(
                json.dumps({"run_code": run_code, "step_index": step_index, "role": role, "camera": "none"}, indent=2),
                encoding="utf-8",
            )
            saved.append({"role": role, "path": str(path), "file_name": path.name, "frame_id": 0})
        manifest_path = Path(output_dir) / f"{run_code}_step_{int(step_index):04d}_PAIR_manifest.json"
        manifest_path.write_text(json.dumps({"run_code": run_code, "step_index": step_index, "saved": saved}, indent=2), encoding="utf-8")
        return {"step_index": int(step_index), "pair_time_delta_s": 0.0, "saved": saved, "manifest_path": str(manifest_path)}


# ------------------------------------------------------------
# Test workflow
# ------------------------------------------------------------

def build_recipe(steps: int) -> List[List[int]]:
    return [[i, 1000 + 1000 * i, 2000 + 1000 * i] for i in range(steps)]


def run_test(
    host: str,
    port: int,
    timeout: float,
    steps: int,
    poll_interval: float,
    strict_clear: bool,
    drain_startup: bool,
    camera_host: str,
    camera_port: int,
    camera_timeout: float,
    no_camera: bool,
    run_code: str,
    image_output_dir: str,
    max_frame_age: float,
    max_pair_delta: float,
) -> None:
    recipe = build_recipe(steps)

    camera_context = NullCameraPairClient() if no_camera else CameraPairClient(camera_host, camera_port, timeout=camera_timeout)

    with SlmpClient(host, port, timeout=timeout) as client, camera_context as camera:
        tester = WorkflowTester(
            client,
            poll_interval=poll_interval,
            timeout=timeout,
            strict_clear=strict_clear,
        )

        camera.start()
        camera_pair = camera.wait_pair_ready_and_fresh(
            timeout=camera_timeout,
            poll_interval=poll_interval,
            max_age_s=max_frame_age,
            max_pair_delta_s=max_pair_delta,
        )
        print(f"Camera pair ready/fresh: {camera_pair}")

        tester.clear_pc_side()
        if drain_startup:
            tester.drain_stale_plc_events()

        tester.send_pc_event(EVT_PC_READY)
        tester.wait_plc_event(EVT_PLC_READY)

        tester.send_pc_event(EVT_SET_MODE_SEMI_AUTO)
        tester.wait_plc_event(EVT_MODE_CHANGED)

        tester.send_pc_event(EVT_RECIPE_DOWNLOAD_START, [steps])
        for row in recipe:
            tester.send_pc_event(EVT_RECIPE_STEP_DATA, row)
        tester.send_pc_event(EVT_RECIPE_DOWNLOAD_END)
        tester.wait_plc_event(EVT_RECIPE_LOADED)

        tester.send_pc_event(EVT_START_RUN)
        tester.wait_plc_event(EVT_RUN_STARTED)

        completed_steps = 0
        saved_pairs: List[dict] = []
        saved_images: List[dict] = []

        while True:
            event = tester.wait_any_plc_event()

            if event.event_type == EVT_SEMI_STEP_STARTED:
                tester.ack_and_wait_gone(event)

            elif event.event_type == EVT_POSITION_REACHED:
                tester.ack_and_wait_gone(event)

            elif event.event_type == EVT_CAPTURE_AUTH_REQUEST:
                step_index = event.payload[0]
                tester.ack_and_wait_gone(event)

                print(f"Checking TOP/BOTTOM camera pair before authorizing capture for step {step_index}")
                camera.wait_pair_ready_and_fresh(
                    timeout=camera_timeout,
                    poll_interval=poll_interval,
                    max_age_s=max_frame_age,
                    max_pair_delta_s=max_pair_delta,
                )
                print(f"Authorizing paired capture for step {step_index}")
                tester.send_pc_event(EVT_CAPTURE_AUTHORIZED, [step_index])

            elif event.event_type == EVT_CAPTURE_WINDOW_OPEN:
                step_index = event.payload[0]
                tester.ack_and_wait_gone(event)

                print(f"Saving paired TOP/BOTTOM camera frames for step {step_index}")
                pair = camera.save_pair(
                    run_code=run_code,
                    step_index=step_index,
                    output_dir=image_output_dir,
                    max_age_s=max_frame_age,
                    max_pair_delta_s=max_pair_delta,
                )
                saved_pairs.append(pair)
                saved_images.extend(pair.get("saved", []))
                print(f"Saved pair metadata: {pair}")

                # payload[0] = step index; payload[1] = save status 1=OK; payload[2] = number of images saved
                tester.send_pc_event(EVT_CAPTURE_DONE, [step_index, 1, len(pair.get("saved", []))])

            elif event.event_type == EVT_CAPTURE_WINDOW_CLOSED:
                tester.ack_and_wait_gone(event)

            elif event.event_type == EVT_STEP_COMPLETE:
                completed_steps += 1
                tester.ack_and_wait_gone(event)

            elif event.event_type == EVT_RUN_COMPLETE:
                tester.ack_and_wait_gone(event)
                break

            elif event.event_type == EVT_PLC_ERROR:
                tester.ack_and_wait_gone(event)
                tester.print_mailboxes()
                raise RuntimeError(f"PLC error event received: payload={event.payload}")

            else:
                tester.ack_and_wait_gone(event)
                tester.print_mailboxes()
                raise RuntimeError(f"Unexpected PLC event: {event.event_type} ({event.name})")

        if completed_steps != steps:
            tester.print_mailboxes()
            raise RuntimeError(f"Expected {steps} completed steps, got {completed_steps}")

        if len(saved_pairs) != steps:
            raise RuntimeError(f"Expected {steps} saved pairs, got {len(saved_pairs)}")

        expected_images = steps * 2
        if len(saved_images) != expected_images:
            raise RuntimeError(f"Expected {expected_images} saved images, got {len(saved_images)}")

        tester.send_pc_event(EVT_STOP_RUN)
        tester.wait_plc_event(EVT_RUN_STOPPED)

        tester.print_mailboxes()
        print("\nSaved pair manifests:")
        for pair in saved_pairs:
            print(f"  {pair.get('manifest_path')}")
        print("\nSaved image files:")
        for saved in saved_images:
            print(f"  [{saved.get('role')}] {saved.get('path')}")
        print("\nWorkflow + dual-camera pair test completed successfully.")


def main() -> None:
    parser = argparse.ArgumentParser(description="DUO_AOI PC workflow + dual-camera pair test v4")
    parser.add_argument("--host", required=True, help="PLC IP address or simulator host")
    parser.add_argument("--port", type=int, default=1025, help="PLC SLMP/MC TCP port")
    parser.add_argument("--timeout", type=float, default=5.0, help="Timeout in seconds per PLC operation")
    parser.add_argument("--steps", type=int, default=3, help="Number of recipe steps to download and execute")
    parser.add_argument("--poll-interval", type=float, default=0.05, help="Polling interval in seconds")
    parser.add_argument(
        "--strict-clear",
        action="store_true",
        help="Require D200=0 after ACK. Default accepts D201 sequence advancement as well.",
    )
    parser.add_argument(
        "--no-drain-startup",
        action="store_true",
        help="Do not drain stale PLC events at startup.",
    )
    parser.add_argument("--camera-host", default="127.0.0.1", help="Camera service host")
    parser.add_argument("--camera-port", type=int, default=6000, help="Camera service TCP port")
    parser.add_argument("--camera-timeout", type=float, default=5.0, help="Timeout in seconds per camera operation")
    parser.add_argument("--max-frame-age", type=float, default=1.0, help="Maximum allowed age in seconds for each camera frame")
    parser.add_argument("--max-pair-delta", type=float, default=0.5, help="Maximum allowed timestamp difference in seconds between TOP and BOTTOM frames")
    parser.add_argument("--no-camera", action="store_true", help="Use a null camera pair stub instead of the camera service")
    parser.add_argument("--run-code", default="SIM_RUN", help="Run code used in saved capture filenames")
    parser.add_argument("--image-output-dir", default="captures", help="Directory for saved image/capture files")
    args = parser.parse_args()

    run_test(
        host=args.host,
        port=args.port,
        timeout=args.timeout,
        steps=args.steps,
        poll_interval=args.poll_interval,
        strict_clear=args.strict_clear,
        drain_startup=not args.no_drain_startup,
        camera_host=args.camera_host,
        camera_port=args.camera_port,
        camera_timeout=args.camera_timeout,
        no_camera=args.no_camera,
        run_code=args.run_code,
        image_output_dir=args.image_output_dir,
        max_frame_age=args.max_frame_age,
        max_pair_delta=args.max_pair_delta,
    )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped by user.")
