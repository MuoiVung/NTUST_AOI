#!/usr/bin/env python3
"""
DUO_AOI dual-camera service, v10 Spyder-friendly CLI with real IDS acquisition and debug-camera mode.

Main change from the older v5/v6 scripts:
    The command-line interface uses positional modes instead of action flags
    such as --scan-ids-devices. This avoids Spyder %runfile confusion where
    a script argument that begins with -- can be mistaken for a %runfile option.

Spyder examples:
    %runfile path/to/duo_aoi_camera_pair_service_v10_debug.py --args "scan-ids-devices --dummy-camera"
    %runfile path/to/duo_aoi_camera_pair_service_v10_debug.py --args "debug-cameras --dummy-camera --duration-s 10 --display --save-every-s 2"
    %runfile path/to/duo_aoi_camera_pair_service_v10_debug.py --args "serve --host 127.0.0.1 --port 6000 --config camera_config_dual_sim.json"
    %runfile path/to/duo_aoi_camera_pair_service_v10_debug.py --args "ping --host 127.0.0.1 --port 6000"

Terminal examples:
    python duo_aoi_camera_pair_service_v10_debug.py scan-ids-devices --dummy-camera
    python duo_aoi_camera_pair_service_v10_debug.py debug-cameras --dummy-camera --duration-s 10 --display --save-every-s 2
    python duo_aoi_camera_pair_service_v10_debug.py serve --host 127.0.0.1 --port 6000 --config camera_config_dual_sim.json

JSON-lines TCP commands, once the service is running:
    {"cmd": "ping"}
    {"cmd": "start_all"}
    {"cmd": "status"}
    {"cmd": "fresh_pair", "max_age_s": 1.0, "max_pair_delta_s": 0.5}
    {"cmd": "save_pair", "run_code": "RUN001", "step_index": 0, "output_dir": "captures"}
"""

from __future__ import annotations

import argparse
import json
import socket
import socketserver
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Protocol, Sequence, Tuple, cast


DEFAULT_ROLES = ("TOP", "BOTTOM")
IDS_METADATA_BACKENDS = {"ids", "ids_peak", "ids_peak_metadata"}
IDS_ACQUISITION_BACKENDS = {"ids_peak_acquisition", "ids_acquisition", "ids_peak_real", "ids_real"}
IDS_BACKENDS = IDS_METADATA_BACKENDS | IDS_ACQUISITION_BACKENDS
DUMMY_IDS_BACKENDS = {"dummy_ids", "dummy_ids_peak", "dummy_ids_peak_metadata"}


@dataclass(frozen=True)
class FrameInfo:
    role: str
    device_id: str
    frame_id: int
    timestamp: float
    width: int
    height: int
    backend: str
    user_id: str = ""
    serial_number: str = ""
    model_name: str = ""


@dataclass(frozen=True)
class IdsDeviceInfo:
    index: int
    model_name: str
    user_id: str
    serial_number: str
    sensor_name: str
    width_max: int
    height_max: int
    interface_display_name: str
    system_display_name: str
    system_version: str
    openable: bool
    error: str = ""


class CameraController(Protocol):
    role: str
    device_id: str

    @property
    def backend_name(self) -> str:
        ...

    def start(self) -> None:
        ...

    def stop(self) -> None:
        ...

    def latest_frame(self) -> Optional[FrameInfo]:
        ...

    def is_fresh(self, max_age_s: float = 1.0) -> bool:
        ...

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        ...

    def save_latest(self, run_code: str, step_index: int, output_dir: str) -> Dict[str, Any]:
        ...


def normalize_id(value: str) -> str:
    return "".join(ch for ch in str(value).upper() if ch.isalnum() or ch in "_-")


def safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(value))


def saved_record_from_frame(role: str, device_id: str, user_id: str, path: Path, filename: str, frame: FrameInfo) -> Dict[str, Any]:
    return {
        "role": role,
        "device_id": device_id,
        "user_id": user_id,
        "path": str(path),
        "file_name": filename,
        "frame_id": frame.frame_id,
        "timestamp": frame.timestamp,
        "width": frame.width,
        "height": frame.height,
        "backend": frame.backend,
    }


# ------------------------------------------------------------
# Simulated continuous-acquisition controller
# ------------------------------------------------------------

class SimulatedCameraController:
    def __init__(
        self,
        role: str,
        device_id: str,
        user_id: str = "",
        serial_number: str = "",
        model_name: str = "SIM_CAMERA",
        backend_name: str = "sim",
        width: int = 1920,
        height: int = 1200,
        fps: float = 10.0,
        start_delay_s: float = 0.0,
    ):
        self.role = role.upper()
        self.device_id = str(device_id)
        self.user_id = str(user_id or device_id)
        self.serial_number = str(serial_number or device_id)
        self.model_name = str(model_name)
        self._backend_name = str(backend_name)
        self.width = int(width)
        self.height = int(height)
        self.fps = float(fps)
        self.start_delay_s = float(start_delay_s)

        self._lock = threading.RLock()
        self._running = False
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._frame_id = 0
        self._last_frame_time = 0.0
        self._fresh_after_start = False

    @property
    def backend_name(self) -> str:
        return self._backend_name

    def start(self) -> None:
        with self._lock:
            if self._running:
                return
            self._running = True
            self._fresh_after_start = False
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._stop_event.set()
            thread = self._thread
        if thread is not None:
            thread.join(timeout=2.0)
        with self._lock:
            self._thread = None

    def _worker(self) -> None:
        if self.start_delay_s > 0:
            time.sleep(self.start_delay_s)
        period = 1.0 / max(0.1, self.fps)
        next_time = time.monotonic()
        while not self._stop_event.is_set():
            with self._lock:
                if self._running:
                    self._frame_id += 1
                    self._last_frame_time = time.time()
                    self._fresh_after_start = True
            next_time += period
            time.sleep(max(0.0, next_time - time.monotonic()))

    def latest_frame_locked(self) -> Optional[FrameInfo]:
        if self._frame_id <= 0:
            return None
        return FrameInfo(
            role=self.role,
            device_id=self.device_id,
            user_id=self.user_id,
            serial_number=self.serial_number,
            model_name=self.model_name,
            frame_id=self._frame_id,
            timestamp=self._last_frame_time,
            width=self.width,
            height=self.height,
            backend=self.backend_name,
        )

    def latest_frame(self) -> Optional[FrameInfo]:
        with self._lock:
            return self.latest_frame_locked()

    def is_fresh(self, max_age_s: float = 1.0) -> bool:
        now = time.time()
        with self._lock:
            return (
                self._running
                and self._fresh_after_start
                and self._frame_id > 0
                and (now - self._last_frame_time) <= float(max_age_s)
            )

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        with self._lock:
            latest = self.latest_frame_locked()
            age_s = None if self._last_frame_time <= 0 else max(0.0, time.time() - self._last_frame_time)
            fresh = (
                self._running
                and self._fresh_after_start
                and self._frame_id > 0
                and age_s is not None
                and age_s <= float(max_age_s)
            )
            return {
                "role": self.role,
                "device_id": self.device_id,
                "user_id": self.user_id,
                "serial_number": self.serial_number,
                "model_name": self.model_name,
                "backend": self.backend_name,
                "running": self._running,
                "ready": self._running,
                "fresh": bool(fresh),
                "frame_id": self._frame_id,
                "last_frame_time": self._last_frame_time,
                "age_s": age_s,
                "latest_frame": asdict(latest) if latest else None,
            }

    def save_latest(self, run_code: str, step_index: int, output_dir: str) -> Dict[str, Any]:
        with self._lock:
            if not self._running:
                raise RuntimeError(f"camera {self.role} is not running")
            frame = self.latest_frame_locked()
            if frame is None:
                raise RuntimeError(f"camera {self.role} has no frame")

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_run = safe_name(run_code)
        safe_role = safe_name(self.role)
        suffix = "ids_metadata" if "ids" in self.backend_name else "frame"
        filename = f"{safe_run}_step_{int(step_index):04d}_{safe_role}_{suffix}_{frame.frame_id:08d}.json"
        path = out_dir / filename

        record = {
            "capture_type": f"{self.backend_name}_dual_camera_frame",
            "run_code": run_code,
            "step_index": int(step_index),
            "role": self.role,
            "device_id": self.device_id,
            "user_id": self.user_id,
            "serial_number": self.serial_number,
            "model_name": self.model_name,
            "saved_at": time.time(),
            "frame": asdict(frame),
        }
        path.write_text(json.dumps(record, indent=2), encoding="utf-8")
        return saved_record_from_frame(self.role, self.device_id, self.user_id, path, filename, frame)


# ------------------------------------------------------------
# IDS peak discovery and dummy discovery
# ------------------------------------------------------------

class IdsPeakRuntime:
    _lock = threading.RLock()
    _refs = 0
    _ids_peak = None
    _ids_peak_afl = None
    _afl_initialized = False

    @classmethod
    def acquire(cls, init_afl: bool = False):
        """Initialize ids_peak lazily.

        If init_afl=True, also initialize ids_peak_afl for the DefaultPipeline/
        BasicAutoFeatures path used by the real acquisition controller.
        """
        with cls._lock:
            if cls._ids_peak is None:
                from ids_peak import ids_peak  # type: ignore
                cls._ids_peak = ids_peak
            if cls._refs == 0:
                cls._ids_peak.Library.Initialize()
            cls._refs += 1

            if init_afl and not cls._afl_initialized:
                from ids_peak_afl import ids_peak_afl  # type: ignore
                cls._ids_peak_afl = ids_peak_afl
                cls._ids_peak_afl.Library.Init()
                cls._afl_initialized = True

            return cls._ids_peak

    @classmethod
    def release(cls) -> None:
        with cls._lock:
            if cls._refs <= 0:
                return
            cls._refs -= 1
            if cls._refs == 0 and cls._ids_peak is not None:
                cls._ids_peak.Library.Close()


def _read_string_node(nodemap: Any, node_name: str, default: str = "") -> str:
    try:
        return str(cast(Any, nodemap.FindNode(node_name)).Value())
    except Exception:
        return default


def _read_int_node(nodemap: Any, node_name: str, default: int = 0) -> int:
    try:
        return int(cast(Any, nodemap.FindNode(node_name)).Value())
    except Exception:
        return default


def discover_ids_peak_devices() -> List[IdsDeviceInfo]:
    ids_peak = IdsPeakRuntime.acquire()
    try:
        manager = ids_peak.DeviceManager.Instance()
        manager.Update()
        results: List[IdsDeviceInfo] = []
        for index, desc in enumerate(manager.Devices()):
            model_name = ""
            user_id = ""
            serial_number = ""
            sensor_name = ""
            width_max = 0
            height_max = 0
            interface_display_name = ""
            system_display_name = ""
            system_version = ""
            openable = False
            error = ""

            try:
                model_name = str(desc.ModelName())
            except Exception:
                pass
            try:
                interface_display_name = str(desc.ParentInterface().DisplayName())
                system_display_name = str(desc.ParentInterface().ParentSystem().DisplayName())
                system_version = str(desc.ParentInterface().ParentSystem().Version())
            except Exception:
                pass
            try:
                openable = bool(desc.IsOpenable(ids_peak.DeviceAccessType_Control))
            except Exception:
                openable = False

            if openable:
                device = None
                try:
                    device = desc.OpenDevice(ids_peak.DeviceAccessType_Control)
                    nodemap = device.RemoteDevice().NodeMaps()[0]
                    model_name = _read_string_node(nodemap, "DeviceModelName", model_name)
                    user_id = _read_string_node(nodemap, "DeviceUserID", "")
                    serial_number = _read_string_node(nodemap, "DeviceSerialNumber", "")
                    sensor_name = _read_string_node(nodemap, "SensorName", "")
                    width_max = _read_int_node(nodemap, "WidthMax", 0)
                    height_max = _read_int_node(nodemap, "HeightMax", 0)
                except Exception as exc:
                    error = str(exc)
                finally:
                    try:
                        del device
                    except Exception:
                        pass

            results.append(
                IdsDeviceInfo(
                    index=index,
                    model_name=model_name,
                    user_id=user_id,
                    serial_number=serial_number,
                    sensor_name=sensor_name,
                    width_max=width_max,
                    height_max=height_max,
                    interface_display_name=interface_display_name,
                    system_display_name=system_display_name,
                    system_version=system_version,
                    openable=openable,
                    error=error,
                )
            )
        return results
    finally:
        IdsPeakRuntime.release()


def discover_dummy_ids_devices() -> List[IdsDeviceInfo]:
    return [
        IdsDeviceInfo(
            index=0,
            model_name="DUMMY_IDS_CAMERA",
            user_id="TOP",
            serial_number="DUMMY_TOP_001",
            sensor_name="DUMMY_SENSOR",
            width_max=1920,
            height_max=1200,
            interface_display_name="DUMMY_INTERFACE",
            system_display_name="DUMMY_SYSTEM",
            system_version="1.0",
            openable=True,
        ),
        IdsDeviceInfo(
            index=1,
            model_name="DUMMY_IDS_CAMERA",
            user_id="BOTTOM",
            serial_number="DUMMY_BOTTOM_001",
            sensor_name="DUMMY_SENSOR",
            width_max=1920,
            height_max=1200,
            interface_display_name="DUMMY_INTERFACE",
            system_display_name="DUMMY_SYSTEM",
            system_version="1.0",
            openable=True,
        ),
    ]


def find_device_for_role_from_list(
    devices: Sequence[IdsDeviceInfo],
    role: str,
    expected_user_id: str = "",
    expected_serial: str = "",
    expected_device_id: str = "",
    role_keywords: Optional[Sequence[str]] = None,
) -> IdsDeviceInfo:
    role_key = role.upper()
    expected_user_id_norm = normalize_id(expected_user_id)
    expected_serial_norm = normalize_id(expected_serial)
    expected_device_id_norm = normalize_id(expected_device_id)
    keyword_norms = [normalize_id(item) for item in (role_keywords or [role_key])]

    candidates: List[Tuple[int, IdsDeviceInfo, str]] = []
    for dev in devices:
        user_norm = normalize_id(dev.user_id)
        serial_norm = normalize_id(dev.serial_number)
        model_norm = normalize_id(dev.model_name)

        if expected_user_id_norm and user_norm == expected_user_id_norm:
            candidates.append((100, dev, "exact DeviceUserID match"))
        elif expected_serial_norm and serial_norm == expected_serial_norm:
            candidates.append((90, dev, "exact DeviceSerialNumber match"))
        elif expected_device_id_norm and expected_device_id_norm in {user_norm, serial_norm, model_norm}:
            candidates.append((80, dev, "device_id matched user_id/serial/model"))
        elif keyword_norms and any(k and k in user_norm for k in keyword_norms):
            candidates.append((50, dev, "role keyword found in DeviceUserID"))

    if not candidates:
        available = [asdict(dev) for dev in devices]
        raise RuntimeError(
            f"could not assign IDS camera for role {role_key}. "
            f"Expected user_id={expected_user_id!r}, serial={expected_serial!r}, device_id={expected_device_id!r}, "
            f"role_keywords={list(role_keywords or [role_key])}. Available={available}"
        )

    candidates.sort(key=lambda item: item[0], reverse=True)
    best_score, best, _reason = candidates[0]
    tied = [item for item in candidates if item[0] == best_score]
    if len(tied) > 1:
        raise RuntimeError(
            f"ambiguous IDS assignment for role {role_key}: "
            f"{[(asdict(dev), reason_text) for _, dev, reason_text in tied]}"
        )
    return best


def find_ids_device_for_role(
    role: str,
    expected_user_id: str = "",
    expected_serial: str = "",
    expected_device_id: str = "",
    role_keywords: Optional[Sequence[str]] = None,
) -> IdsDeviceInfo:
    return find_device_for_role_from_list(
        discover_ids_peak_devices(),
        role=role,
        expected_user_id=expected_user_id,
        expected_serial=expected_serial,
        expected_device_id=expected_device_id,
        role_keywords=role_keywords,
    )


class IdsPeakMetadataCameraController:
    def __init__(
        self,
        role: str,
        expected_user_id: str = "",
        expected_serial: str = "",
        expected_device_id: str = "",
        role_keywords: Optional[Sequence[str]] = None,
        fps: float = 10.0,
    ):
        self.role = role.upper()
        self.expected_user_id = str(expected_user_id or "")
        self.expected_serial = str(expected_serial or "")
        self.expected_device_id = str(expected_device_id or "")
        self.role_keywords = list(role_keywords or [self.role])
        self.fps = float(fps)

        self.device_id = self.expected_device_id or self.expected_user_id or self.expected_serial or self.role
        self.user_id = ""
        self.serial_number = ""
        self.model_name = ""
        self.width = 0
        self.height = 0
        self._device_info: Optional[IdsDeviceInfo] = None

        self._lock = threading.RLock()
        self._running = False
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._frame_id = 0
        self._last_frame_time = 0.0
        self._ready = False
        self._ids_peak = None
        self._device = None

    @property
    def backend_name(self) -> str:
        return "ids_peak_metadata"

    def start(self) -> None:
        with self._lock:
            if self._running:
                return

        info = find_ids_device_for_role(
            role=self.role,
            expected_user_id=self.expected_user_id,
            expected_serial=self.expected_serial,
            expected_device_id=self.expected_device_id,
            role_keywords=self.role_keywords,
        )
        ids_peak = IdsPeakRuntime.acquire()
        manager = ids_peak.DeviceManager.Instance()
        manager.Update()
        if info.index >= len(manager.Devices()):
            IdsPeakRuntime.release()
            raise RuntimeError(f"IDS device index {info.index} disappeared before opening")
        desc = manager.Devices()[info.index]
        device = desc.OpenDevice(ids_peak.DeviceAccessType_Control)

        with self._lock:
            self._ids_peak = ids_peak
            self._device = device
            self._device_info = info
            self.user_id = info.user_id
            self.serial_number = info.serial_number
            self.model_name = info.model_name
            self.width = info.width_max
            self.height = info.height_max
            self.device_id = info.serial_number or info.user_id or f"IDS_INDEX_{info.index}"
            self._running = True
            self._ready = True
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._ready = False
            self._stop_event.set()
            thread = self._thread
            self._thread = None
            self._device = None
            has_library_ref = self._ids_peak is not None
            self._ids_peak = None
        if thread is not None:
            thread.join(timeout=2.0)
        if has_library_ref:
            IdsPeakRuntime.release()

    def _worker(self) -> None:
        period = 1.0 / max(0.1, self.fps)
        next_time = time.monotonic()
        while not self._stop_event.is_set():
            with self._lock:
                if self._running and self._ready:
                    self._frame_id += 1
                    self._last_frame_time = time.time()
            next_time += period
            time.sleep(max(0.0, next_time - time.monotonic()))

    def latest_frame_locked(self) -> Optional[FrameInfo]:
        if self._frame_id <= 0:
            return None
        return FrameInfo(
            role=self.role,
            device_id=self.device_id,
            user_id=self.user_id,
            serial_number=self.serial_number,
            model_name=self.model_name,
            frame_id=self._frame_id,
            timestamp=self._last_frame_time,
            width=self.width,
            height=self.height,
            backend=self.backend_name,
        )

    def latest_frame(self) -> Optional[FrameInfo]:
        with self._lock:
            return self.latest_frame_locked()

    def is_fresh(self, max_age_s: float = 1.0) -> bool:
        with self._lock:
            return (
                self._running
                and self._ready
                and self._frame_id > 0
                and (time.time() - self._last_frame_time) <= float(max_age_s)
            )

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        with self._lock:
            latest = self.latest_frame_locked()
            age_s = None if self._last_frame_time <= 0 else max(0.0, time.time() - self._last_frame_time)
            fresh = (
                self._running
                and self._ready
                and self._frame_id > 0
                and age_s is not None
                and age_s <= float(max_age_s)
            )
            return {
                "role": self.role,
                "device_id": self.device_id,
                "user_id": self.user_id,
                "serial_number": self.serial_number,
                "model_name": self.model_name,
                "backend": self.backend_name,
                "running": self._running,
                "ready": bool(self._ready),
                "fresh": bool(fresh),
                "frame_id": self._frame_id,
                "last_frame_time": self._last_frame_time,
                "age_s": age_s,
                "latest_frame": asdict(latest) if latest else None,
                "matched_device": asdict(self._device_info) if self._device_info else None,
                "note": "IDS setup backend validates DeviceUserID mapping and saves metadata records.",
            }

    def save_latest(self, run_code: str, step_index: int, output_dir: str) -> Dict[str, Any]:
        with self._lock:
            if not self._running or not self._ready:
                raise RuntimeError(f"IDS camera {self.role} is not ready")
            frame = self.latest_frame_locked()
            if frame is None:
                raise RuntimeError(f"IDS camera {self.role} has no frame metadata")

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_run = safe_name(run_code)
        safe_role = safe_name(self.role)
        filename = f"{safe_run}_step_{int(step_index):04d}_{safe_role}_ids_metadata_{frame.frame_id:08d}.json"
        path = out_dir / filename
        record = {
            "capture_type": "ids_peak_metadata_capture",
            "run_code": run_code,
            "step_index": int(step_index),
            "role": self.role,
            "device_id": self.device_id,
            "user_id": self.user_id,
            "serial_number": self.serial_number,
            "model_name": self.model_name,
            "saved_at": time.time(),
            "frame": asdict(frame),
            "note": "This file confirms TOP/BOTTOM IDS DeviceUserID pairing. Replace with image acquisition save in production.",
        }
        path.write_text(json.dumps(record, indent=2), encoding="utf-8")
        return saved_record_from_frame(self.role, self.device_id, self.user_id, path, filename, frame)

class IdsPeakAcquisitionCameraController:
    """Real IDS peak acquisition controller.

    This controller is the production version of the metadata controller. It:
      - finds the physical IDS camera by DeviceUserID / serial / role keyword,
      - opens the device with control access,
      - optionally loads a .cset file,
      - optionally loads DefaultPipeline settings from JSON,
      - configures software trigger acquisition,
      - runs a non-blocking worker thread that keeps the latest processed frame,
      - saves the latest real frame on save_latest().

    It intentionally does not use cv2.imshow(), so it can run as a service.
    """

    def __init__(
        self,
        role: str,
        expected_user_id: str = "",
        expected_serial: str = "",
        expected_device_id: str = "",
        role_keywords: Optional[Sequence[str]] = None,
        fps: float = 10.0,
        cset_path: str = "",
        pipeline_settings_json: str = "",
        image_extension: str = "png",
        timeout_ms: int = 1000,
        save_numpy: bool = False,
    ):
        self.role = role.upper()
        self.expected_user_id = str(expected_user_id or "")
        self.expected_serial = str(expected_serial or "")
        self.expected_device_id = str(expected_device_id or "")
        self.role_keywords = list(role_keywords or [self.role])
        self.fps = float(fps)
        self.cset_path = str(cset_path or "")
        self.pipeline_settings_json = str(pipeline_settings_json or "")
        self.image_extension = str(image_extension or "png").lstrip(".").lower() or "png"
        self.timeout_ms = int(timeout_ms)
        self.save_numpy = bool(save_numpy)

        self.device_id = self.expected_device_id or self.expected_user_id or self.expected_serial or self.role
        self.user_id = ""
        self.serial_number = ""
        self.model_name = ""
        self.width = 0
        self.height = 0
        self._device_info: Optional[IdsDeviceInfo] = None

        self._lock = threading.RLock()
        self._running = False
        self._ready = False
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._frame_id = 0
        self._last_frame_time = 0.0
        self._last_error = ""
        self._latest_frame_array: Any = None

        self._ids_peak = None
        self._device = None
        self._nodemap = None
        self._datastream = None
        self._pipeline = None
        self._announced_buffers: List[Any] = []

    @property
    def backend_name(self) -> str:
        return "ids_peak_acquisition"

    def start(self) -> None:
        with self._lock:
            if self._running:
                return

        info = find_ids_device_for_role(
            role=self.role,
            expected_user_id=self.expected_user_id,
            expected_serial=self.expected_serial,
            expected_device_id=self.expected_device_id,
            role_keywords=self.role_keywords,
        )
        ids_peak = IdsPeakRuntime.acquire(init_afl=True)
        try:
            manager = ids_peak.DeviceManager.Instance()
            manager.Update()
            if info.index >= len(manager.Devices()):
                raise RuntimeError(f"IDS device index {info.index} disappeared before opening")

            desc = manager.Devices()[info.index]
            device = desc.OpenDevice(ids_peak.DeviceAccessType_Control)
            nodemap = device.RemoteDevice().NodeMaps()[0]

            self._try_load_default_userset(ids_peak, nodemap)
            if self.cset_path:
                self._load_cset(device, self.cset_path)

            self._configure_software_trigger(nodemap)

            datastreams = device.DataStreams()
            if self._ids_vector_empty(datastreams):
                raise RuntimeError(f"IDS camera {self.role} has no DataStream")
            datastream = datastreams[0].OpenDataStream()

            payload_size = int(nodemap.FindNode("PayloadSize").Value())
            buffer_count = int(datastream.NumBuffersAnnouncedMinRequired())
            buffers: List[Any] = []
            for _ in range(max(1, buffer_count)):
                buffer = datastream.AllocAndAnnounceBuffer(payload_size)
                datastream.QueueBuffer(buffer)
                buffers.append(buffer)

            pipeline = self._create_pipeline(device)

            try:
                nodemap.FindNode("TLParamsLocked").SetValue(1)
            except Exception:
                pass

            datastream.StartAcquisition()
            nodemap.FindNode("AcquisitionStart").Execute()
            nodemap.FindNode("AcquisitionStart").WaitUntilDone()

        except Exception:
            IdsPeakRuntime.release()
            raise

        with self._lock:
            self._ids_peak = ids_peak
            self._device = device
            self._nodemap = nodemap
            self._datastream = datastream
            self._pipeline = pipeline
            self._announced_buffers = buffers
            self._device_info = info
            self.user_id = info.user_id
            self.serial_number = info.serial_number
            self.model_name = info.model_name
            self.width = int(info.width_max or 0)
            self.height = int(info.height_max or 0)
            self.device_id = info.serial_number or info.user_id or f"IDS_INDEX_{info.index}"
            self._running = True
            self._ready = True
            self._last_error = ""
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        with self._lock:
            if not self._running and not self._ready:
                return
            self._running = False
            self._ready = False
            self._stop_event.set()
            thread = self._thread
            self._thread = None

        if thread is not None:
            thread.join(timeout=2.5)

        with self._lock:
            ids_peak = self._ids_peak
            nodemap = self._nodemap
            datastream = self._datastream
            self._ids_peak = None
            self._device = None
            self._nodemap = None
            self._datastream = None
            self._pipeline = None
            self._announced_buffers = []
            self._latest_frame_array = None

        if nodemap is not None:
            try:
                nodemap.FindNode("AcquisitionStop").Execute()
                nodemap.FindNode("AcquisitionStop").WaitUntilDone()
            except Exception:
                pass
            try:
                nodemap.FindNode("TLParamsLocked").SetValue(0)
            except Exception:
                pass
        if datastream is not None:
            try:
                datastream.StopAcquisition()
            except Exception:
                pass
            # Some ids_peak versions provide Flush/KillWait. Use only if present.
            for method_name in ("KillWait", "Flush"):
                try:
                    method = getattr(datastream, method_name, None)
                    if callable(method):
                        method()
                except Exception:
                    pass
        if ids_peak is not None:
            IdsPeakRuntime.release()

    def _worker(self) -> None:
        while not self._stop_event.is_set():
            buffer = None
            try:
                with self._lock:
                    nodemap = self._nodemap
                    datastream = self._datastream
                    pipeline = self._pipeline
                    ids_peak = self._ids_peak
                    running = self._running and self._ready
                if not running or nodemap is None or datastream is None or pipeline is None or ids_peak is None:
                    time.sleep(0.01)
                    continue

                nodemap.FindNode("TriggerSoftware").Execute()
                timeout = getattr(ids_peak.Timeout, "INFINITE_TIMEOUT") if self.timeout_ms <= 0 else self.timeout_ms
                buffer = datastream.WaitForFinishedBuffer(timeout)
                image_view = buffer.ToImageView()
                image = pipeline.process(image_view)
                array = image.to_numpy_array()

                with self._lock:
                    self._frame_id += 1
                    self._last_frame_time = time.time()
                    self._latest_frame_array = array.copy()
                    if self.width <= 0:
                        try:
                            self.width = int(array.shape[1])
                            self.height = int(array.shape[0])
                        except Exception:
                            pass
                    self._last_error = ""

            except Exception as exc:
                with self._lock:
                    self._last_error = str(exc)
                # Avoid a tight error loop if hardware is temporarily unavailable.
                time.sleep(0.05)
            finally:
                if buffer is not None:
                    try:
                        with self._lock:
                            datastream = self._datastream
                        if datastream is not None:
                            datastream.QueueBuffer(buffer)
                    except Exception as exc:
                        with self._lock:
                            self._last_error = f"QueueBuffer failed: {exc}"

    def latest_frame_locked(self) -> Optional[FrameInfo]:
        if self._frame_id <= 0:
            return None
        return FrameInfo(
            role=self.role,
            device_id=self.device_id,
            user_id=self.user_id,
            serial_number=self.serial_number,
            model_name=self.model_name,
            frame_id=self._frame_id,
            timestamp=self._last_frame_time,
            width=int(self.width),
            height=int(self.height),
            backend=self.backend_name,
        )

    def latest_frame(self) -> Optional[FrameInfo]:
        with self._lock:
            return self.latest_frame_locked()

    def is_fresh(self, max_age_s: float = 1.0) -> bool:
        with self._lock:
            return (
                self._running
                and self._ready
                and self._frame_id > 0
                and (time.time() - self._last_frame_time) <= float(max_age_s)
            )

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        with self._lock:
            latest = self.latest_frame_locked()
            age_s = None if self._last_frame_time <= 0 else max(0.0, time.time() - self._last_frame_time)
            fresh = (
                self._running
                and self._ready
                and self._frame_id > 0
                and age_s is not None
                and age_s <= float(max_age_s)
            )
            return {
                "role": self.role,
                "device_id": self.device_id,
                "user_id": self.user_id,
                "serial_number": self.serial_number,
                "model_name": self.model_name,
                "backend": self.backend_name,
                "running": self._running,
                "ready": bool(self._ready),
                "fresh": bool(fresh),
                "frame_id": self._frame_id,
                "last_frame_time": self._last_frame_time,
                "age_s": age_s,
                "latest_frame": asdict(latest) if latest else None,
                "matched_device": asdict(self._device_info) if self._device_info else None,
                "last_error": self._last_error,
                "cset_path": self.cset_path,
                "pipeline_settings_json": self.pipeline_settings_json,
            }

    def save_latest(self, run_code: str, step_index: int, output_dir: str) -> Dict[str, Any]:
        with self._lock:
            if not self._running or not self._ready:
                raise RuntimeError(f"IDS camera {self.role} is not ready")
            frame = self.latest_frame_locked()
            if frame is None or self._latest_frame_array is None:
                raise RuntimeError(f"IDS camera {self.role} has no image frame")
            array = self._latest_frame_array.copy()

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_run = safe_name(run_code)
        safe_role = safe_name(self.role)
        filename = f"{safe_run}_step_{int(step_index):04d}_{safe_role}_frame_{frame.frame_id:08d}.{self.image_extension}"
        path = out_dir / filename

        self._save_image_array(path, array)
        if self.save_numpy:
            try:
                import numpy as np  # type: ignore
                np.save(str(path.with_suffix(path.suffix + ".npy")), array)
            except Exception:
                pass
        return saved_record_from_frame(self.role, self.device_id, self.user_id, path, filename, frame)

    def _create_pipeline(self, device: Any) -> Any:
        from ids_peak_icv.pipeline import DefaultPipeline  # type: ignore
        from ids_peak_afl.pipeline import BasicAutoFeatures  # type: ignore

        autofeatures = BasicAutoFeatures(device)
        pipeline = DefaultPipeline()
        pipeline.autofeature_module = autofeatures

        if self.pipeline_settings_json:
            p = Path(self.pipeline_settings_json).expanduser().resolve()
            if p.exists():
                pipeline.import_settings_from_file(str(p))
            else:
                # Missing pipeline JSON should not prevent acquisition; use defaults.
                self._last_error = f"pipeline settings not found: {p}; using defaults"
        return pipeline

    def _save_image_array(self, path: Path, array: Any) -> None:
        # Prefer OpenCV because the original working code uses OpenCV/Pipeline arrays.
        try:
            import cv2  # type: ignore
            ok = cv2.imwrite(str(path), array)
            if ok:
                return
        except Exception:
            pass

        # Fallback to PIL if OpenCV is unavailable or refuses the array.
        from PIL import Image  # type: ignore
        img = Image.fromarray(array)
        img.save(path)

    def _load_cset(self, device: Any, cset_path: str) -> None:
        p = Path(cset_path).expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(f".cset file not found: {p}")
        remote_nodemap = device.RemoteDevice().NodeMaps()[0]
        remote_nodemap.LoadFromFile(str(p))

    def _try_load_default_userset(self, ids_peak: Any, nodemap: Any) -> None:
        try:
            nodemap.FindNode("UserSetSelector").SetCurrentEntry("Default")
            nodemap.FindNode("UserSetLoad").Execute()
            nodemap.FindNode("UserSetLoad").WaitUntilDone()
        except Exception:
            pass

    def _configure_software_trigger(self, nodemap: Any) -> None:
        nodemap.FindNode("TriggerSelector").SetCurrentEntry("ExposureStart")
        nodemap.FindNode("TriggerSource").SetCurrentEntry("Software")
        nodemap.FindNode("TriggerMode").SetCurrentEntry("On")

    def _ids_vector_empty(self, value: Any) -> bool:
        try:
            return bool(value.empty())
        except Exception:
            try:
                return len(value) == 0
            except Exception:
                return False


class DummyIdsMetadataCameraController(SimulatedCameraController):
    def __init__(
        self,
        role: str,
        expected_user_id: str = "",
        expected_serial: str = "",
        expected_device_id: str = "",
        role_keywords: Optional[Sequence[str]] = None,
        fps: float = 10.0,
    ):
        info = find_device_for_role_from_list(
            discover_dummy_ids_devices(),
            role=role,
            expected_user_id=expected_user_id,
            expected_serial=expected_serial,
            expected_device_id=expected_device_id,
            role_keywords=role_keywords,
        )
        super().__init__(
            role=role,
            device_id=info.serial_number or info.user_id or f"DUMMY_IDS_INDEX_{info.index}",
            user_id=info.user_id,
            serial_number=info.serial_number,
            model_name=info.model_name,
            backend_name="dummy_ids_peak_metadata",
            width=info.width_max,
            height=info.height_max,
            fps=fps,
        )
        self._device_info = info

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        status = super().status(max_age_s=max_age_s)
        status["matched_device"] = asdict(self._device_info)
        status["note"] = "Dummy IDS backend validates DeviceUserID TOP/BOTTOM pairing without IDS hardware."
        return status


# ------------------------------------------------------------
# Camera manager and service
# ------------------------------------------------------------

class CameraManager:
    def __init__(self, controllers: Sequence[CameraController]):
        self._controllers: Dict[str, CameraController] = {}
        used_device_ids: Dict[str, str] = {}
        for controller in controllers:
            role = controller.role.upper()
            device_id = str(controller.device_id)
            if role in self._controllers:
                raise ValueError(f"duplicate camera role: {role}")
            if device_id in used_device_ids:
                raise ValueError(f"device_id {device_id!r} assigned to both {used_device_ids[device_id]} and {role}")
            self._controllers[role] = controller
            used_device_ids[device_id] = role

        missing = [role for role in DEFAULT_ROLES if role not in self._controllers]
        if missing:
            raise ValueError(f"missing required camera roles: {missing}")

    @property
    def roles(self) -> List[str]:
        return sorted(self._controllers.keys())

    def get(self, role: str) -> CameraController:
        role_key = str(role).upper()
        if role_key not in self._controllers:
            raise KeyError(f"unknown camera role {role!r}; available roles={self.roles}")
        return self._controllers[role_key]

    def start_all(self) -> None:
        for controller in self._controllers.values():
            controller.start()

    def stop_all(self) -> None:
        for controller in self._controllers.values():
            controller.stop()

    def status(self, max_age_s: float = 1.0) -> Dict[str, Any]:
        camera_status = {role: cam.status(max_age_s=max_age_s) for role, cam in self._controllers.items()}
        pair = self._pair_state(max_age_s=max_age_s, max_pair_delta_s=999999.0)
        return {
            "roles": self.roles,
            "cameras": camera_status,
            "all_ready": all(item["ready"] for item in camera_status.values()),
            "all_fresh": all(item["fresh"] for item in camera_status.values()),
            "pair_time_delta_s": pair.get("pair_time_delta_s"),
        }

    def ready_pair(self) -> Dict[str, Any]:
        statuses = {role: cam.status() for role, cam in self._controllers.items()}
        return {"ready": all(status["ready"] for status in statuses.values()), "statuses": statuses}

    def fresh_pair(self, max_age_s: float = 1.0, max_pair_delta_s: float = 0.5) -> Dict[str, Any]:
        return self._pair_state(max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)

    def _pair_state(self, max_age_s: float, max_pair_delta_s: float) -> Dict[str, Any]:
        statuses = {role: cam.status(max_age_s=max_age_s) for role, cam in self._controllers.items()}
        latest_frames = {role: cam.latest_frame() for role, cam in self._controllers.items()}
        timestamps = [frame.timestamp for frame in latest_frames.values() if frame is not None]
        pair_time_delta_s = None
        if len(timestamps) >= 2:
            pair_time_delta_s = max(timestamps) - min(timestamps)
        all_ready = all(status["ready"] for status in statuses.values())
        all_fresh = all(status["fresh"] for status in statuses.values())
        pair_synchronized = pair_time_delta_s is not None and pair_time_delta_s <= float(max_pair_delta_s)
        return {
            "ready": bool(all_ready),
            "fresh": bool(all_ready and all_fresh and pair_synchronized),
            "all_ready": bool(all_ready),
            "all_fresh": bool(all_fresh),
            "pair_synchronized": bool(pair_synchronized),
            "pair_time_delta_s": pair_time_delta_s,
            "max_age_s": float(max_age_s),
            "max_pair_delta_s": float(max_pair_delta_s),
            "statuses": statuses,
        }

    def save_pair(
        self,
        run_code: str,
        step_index: int,
        output_dir: str,
        max_age_s: float = 1.0,
        max_pair_delta_s: float = 0.5,
    ) -> Dict[str, Any]:
        pair = self.fresh_pair(max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)
        if not pair["fresh"]:
            raise RuntimeError(f"camera pair is not fresh/synchronized: {pair}")

        saved = [self.get(role).save_latest(run_code, step_index, output_dir) for role in DEFAULT_ROLES]
        pair_time_delta_s = None
        if len(saved) >= 2:
            stamps = [item["timestamp"] for item in saved]
            pair_time_delta_s = max(stamps) - min(stamps)

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        manifest_name = f"{safe_name(run_code)}_step_{int(step_index):04d}_PAIR_manifest.json"
        manifest_path = out_dir / manifest_name
        manifest = {
            "capture_type": "dual_camera_pair",
            "run_code": run_code,
            "step_index": int(step_index),
            "saved_at": time.time(),
            "pair_time_delta_s": pair_time_delta_s,
            "saved": saved,
        }
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return {
            "step_index": int(step_index),
            "pair_time_delta_s": pair_time_delta_s,
            "saved": saved,
            "manifest_path": str(manifest_path),
            "manifest_file_name": manifest_name,
        }


class CameraService:
    def __init__(self, manager: CameraManager, verbose: bool = True, dummy_discovery: bool = False):
        self.manager = manager
        self.verbose = verbose
        self.dummy_discovery = dummy_discovery

    def handle_command(self, request: Dict[str, Any]) -> Dict[str, Any]:
        cmd = str(request.get("cmd", "")).strip().lower().replace("-", "_")
        max_age_s = float(request.get("max_age_s", 1.0))
        max_pair_delta_s = float(request.get("max_pair_delta_s", 0.5))

        if cmd == "ping":
            return {"ok": True, "message": "pong", "roles": self.manager.roles}

        if cmd in {"discover", "discover_ids", "scan_ids", "scan_ids_devices"}:
            if self.dummy_discovery:
                devices = [asdict(item) for item in discover_dummy_ids_devices()]
            else:
                devices = [asdict(item) for item in discover_ids_peak_devices()]
            return {"ok": True, "devices": devices}

        if cmd in {"start", "start_all"}:
            self.manager.start_all()
            return {"ok": True, "message": "started", "status": self.manager.status(max_age_s=max_age_s)}

        if cmd in {"stop", "stop_all"}:
            self.manager.stop_all()
            return {"ok": True, "message": "stopped", "status": self.manager.status(max_age_s=max_age_s)}

        if cmd == "status":
            return {"ok": True, "status": self.manager.status(max_age_s=max_age_s)}

        if cmd == "ready_pair":
            return {"ok": True, **self.manager.ready_pair()}

        if cmd == "fresh_pair":
            return {"ok": True, **self.manager.fresh_pair(max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)}

        if cmd == "ready":
            role = str(request.get("role", "TOP"))
            status = self.manager.get(role).status(max_age_s=max_age_s)
            return {"ok": True, "ready": bool(status["ready"]), "status": status}

        if cmd == "fresh":
            role = str(request.get("role", "TOP"))
            status = self.manager.get(role).status(max_age_s=max_age_s)
            return {"ok": True, "fresh": bool(status["fresh"]), "status": status}

        if cmd in {"save", "save_latest"}:
            role = str(request.get("role", "TOP"))
            run_code = str(request.get("run_code", "RUN"))
            step_index = int(request.get("step_index", 0))
            output_dir = str(request.get("output_dir", "captures"))
            saved = self.manager.get(role).save_latest(run_code, step_index, output_dir)
            return {"ok": True, "saved": saved}

        if cmd == "save_pair":
            run_code = str(request.get("run_code", "RUN"))
            step_index = int(request.get("step_index", 0))
            output_dir = str(request.get("output_dir", "captures"))
            result = self.manager.save_pair(run_code, step_index, output_dir, max_age_s=max_age_s, max_pair_delta_s=max_pair_delta_s)
            return {"ok": True, "pair": result}

        return {"ok": False, "error": f"unknown command: {cmd}"}


class JsonLineHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        service: CameraService = self.server.service  # type: ignore[attr-defined]
        for raw_line in self.rfile:
            line = raw_line.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            try:
                request = json.loads(line)
                if not isinstance(request, dict):
                    raise ValueError("request must be a JSON object")
                response = service.handle_command(request)
            except Exception as exc:
                response = {"ok": False, "error": str(exc)}
            if service.verbose:
                print(f"CAMERA SERVICE: request={line} response={response}")
            self.wfile.write((json.dumps(response) + "\n").encode("utf-8"))
            self.wfile.flush()


class ThreadedCameraServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address, handler_class, service: CameraService):
        super().__init__(address, handler_class)
        self.service = service




# ------------------------------------------------------------
# Debug-camera helpers
# ------------------------------------------------------------

def _as_uint8_bgr(array: Any) -> Any:
    """Convert an arbitrary NumPy-like image array to uint8 BGR for display/saving."""
    import numpy as np  # type: ignore

    arr = np.asarray(array)
    if arr.ndim == 2:
        arr = np.stack([arr, arr, arr], axis=-1)
    elif arr.ndim == 3 and arr.shape[2] == 1:
        arr = np.repeat(arr, 3, axis=2)
    elif arr.ndim == 3 and arr.shape[2] >= 3:
        arr = arr[:, :, :3]
    else:
        arr = np.zeros((480, 640, 3), dtype=np.uint8)

    if arr.dtype != np.uint8:
        arr_float = arr.astype(np.float32)
        if arr_float.size > 0:
            mn = float(np.nanmin(arr_float))
            mx = float(np.nanmax(arr_float))
            if mx > mn:
                arr_float = (arr_float - mn) * (255.0 / (mx - mn))
            arr = np.clip(arr_float, 0, 255).astype(np.uint8)
        else:
            arr = np.zeros((480, 640, 3), dtype=np.uint8)
    return arr


def _synthetic_debug_frame(role: str, status: Dict[str, Any], width: int = 640, height: int = 360) -> Any:
    import numpy as np  # type: ignore
    try:
        import cv2  # type: ignore
    except Exception:
        cv2 = None

    img = np.zeros((height, width, 3), dtype=np.uint8)
    role_key = role.upper()
    base = 80 if role_key == "TOP" else 130
    img[:, :, 0] = base
    img[:, :, 1] = 35
    img[:, :, 2] = 35 if role_key == "TOP" else 100

    latest = status.get("latest_frame") or {}
    lines = [
        f"{role_key} DEBUG",
        f"backend: {status.get('backend', '')}",
        f"user_id: {status.get('user_id', '')}",
        f"serial: {status.get('serial_number', '')}",
        f"ready: {status.get('ready')} fresh: {status.get('fresh')}",
        f"frame_id: {status.get('frame_id', 0)}",
        f"age_s: {status.get('age_s')}",
        f"size: {latest.get('width', status.get('width', ''))} x {latest.get('height', '')}",
    ]
    if status.get("last_error"):
        lines.append(f"error: {str(status.get('last_error'))[:60]}")

    if cv2 is not None:
        y = 35
        for line in lines:
            cv2.putText(img, line, (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
            y += 30
    return img


def _controller_debug_frame_array(controller: CameraController, status: Dict[str, Any]) -> Any:
    """Return a displayable array for a controller.

    Real IDS acquisition controllers expose _latest_frame_array internally; simulated
    and metadata controllers synthesize a debug panel so the same debug command can
    run without hardware.
    """
    arr = None
    lock = getattr(controller, "_lock", None)
    if lock is not None:
        try:
            with lock:
                raw = getattr(controller, "_latest_frame_array", None)
                if raw is not None:
                    try:
                        arr = raw.copy()
                    except Exception:
                        arr = raw
        except Exception:
            arr = None
    else:
        raw = getattr(controller, "_latest_frame_array", None)
        if raw is not None:
            arr = raw

    if arr is None:
        arr = _synthetic_debug_frame(str(getattr(controller, "role", "CAMERA")), status)
    return _as_uint8_bgr(arr)


def _compose_debug_canvas(manager: CameraManager, max_age_s: float = 1.0) -> Tuple[Any, Dict[str, Any]]:
    import numpy as np  # type: ignore
    try:
        import cv2  # type: ignore
    except Exception:
        cv2 = None

    status = manager.status(max_age_s=max_age_s)
    panels = []
    for role in DEFAULT_ROLES:
        controller = manager.get(role)
        cam_status = status["cameras"].get(role, {})
        frame = _controller_debug_frame_array(controller, cam_status)
        if cv2 is not None:
            target_h = 360
            scale = target_h / max(1, frame.shape[0])
            target_w = max(1, int(frame.shape[1] * scale))
            frame = cv2.resize(frame, (target_w, target_h))
            title = f"{role} | ready={cam_status.get('ready')} fresh={cam_status.get('fresh')} frame={cam_status.get('frame_id')}"
            cv2.putText(frame, title, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
        panels.append(frame)

    if not panels:
        canvas = np.zeros((360, 640, 3), dtype=np.uint8)
    else:
        min_h = min(panel.shape[0] for panel in panels)
        normalized = []
        for panel in panels:
            if panel.shape[0] != min_h and cv2 is not None:
                scale = min_h / max(1, panel.shape[0])
                panel = cv2.resize(panel, (max(1, int(panel.shape[1] * scale)), min_h))
            normalized.append(panel)
        canvas = np.hstack(normalized)
    return canvas, status


def _save_debug_canvas(path: Path, canvas: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        import cv2  # type: ignore
        ok = cv2.imwrite(str(path), canvas)
        if ok:
            return
    except Exception:
        pass
    from PIL import Image  # type: ignore
    Image.fromarray(canvas).save(path)


def run_debug_cameras(args: argparse.Namespace) -> int:
    """Standalone camera debug mode.

    It scans/prints IDS-style camera identities, opens TOP/BOTTOM controllers,
    checks freshness, optionally shows a live two-panel preview, periodically
    saves paired images/metadata, and writes a final debug status JSON.
    """
    if args.dummy_camera:
        devices = discover_dummy_ids_devices()
        print("Dummy IDS devices:")
    else:
        try:
            devices = discover_ids_peak_devices()
            print("IDS devices:")
        except Exception as exc:
            print(f"IDS discovery failed before debug open: {exc}")
            devices = []
    print(json.dumps([asdict(item) for item in devices], indent=2))

    manager = create_manager_from_args(args)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    save_interval = float(args.save_every_s)
    next_save = time.monotonic() + max(0.0, float(args.warmup_s))
    end_time = None if float(args.duration_s) <= 0 else time.monotonic() + float(args.duration_s)
    saved_count = 0
    last_status: Dict[str, Any] = {}

    try:
        manager.start_all()
        if args.warmup_s > 0:
            time.sleep(float(args.warmup_s))

        print("Debug camera mode started.")
        print("Press q in the preview window or Ctrl+C in the console to stop.")

        while True:
            canvas, last_status = _compose_debug_canvas(manager, max_age_s=float(args.max_age_s))
            pair = manager.fresh_pair(max_age_s=float(args.max_age_s), max_pair_delta_s=float(args.max_pair_delta_s))
            now = time.monotonic()

            if save_interval > 0 and now >= next_save:
                try:
                    result = manager.save_pair(
                        run_code=str(args.run_code),
                        step_index=saved_count,
                        output_dir=str(out_dir),
                        max_age_s=float(args.max_age_s),
                        max_pair_delta_s=float(args.max_pair_delta_s),
                    )
                    print(f"Saved pair {saved_count}: {result.get('manifest_path')}")
                    saved_count += 1
                except Exception as exc:
                    print(f"Save pair skipped/failed: {exc}")
                next_save = now + save_interval

            if args.save_preview:
                preview_path = out_dir / f"{safe_name(args.run_code)}_debug_preview_latest.png"
                _save_debug_canvas(preview_path, canvas)

            if args.display:
                import cv2  # type: ignore
                cv2.imshow("DUO_AOI TOP/BOTTOM camera debug", canvas)
                key = cv2.waitKey(max(1, int(float(args.display_delay_ms)))) & 0xFF
                if key == ord("q"):
                    break
            else:
                roles = last_status.get("roles", [])
                print(
                    f"debug status roles={roles} all_ready={last_status.get('all_ready')} "
                    f"all_fresh={last_status.get('all_fresh')} pair_fresh={pair.get('fresh')} "
                    f"pair_dt={pair.get('pair_time_delta_s')}"
                )
                time.sleep(max(0.05, float(args.poll_s)))

            if end_time is not None and time.monotonic() >= end_time:
                break

    except KeyboardInterrupt:
        print("Debug camera mode stopped by user.")
    finally:
        try:
            if args.display:
                import cv2  # type: ignore
                cv2.destroyAllWindows()
        except Exception:
            pass
        final_status = manager.status(max_age_s=float(args.max_age_s))
        status_path = out_dir / f"{safe_name(args.run_code)}_debug_status.json"
        status_path.write_text(json.dumps(final_status, indent=2), encoding="utf-8")
        print(f"Wrote debug status: {status_path}")
        manager.stop_all()

    return 0


# ------------------------------------------------------------
# Config and controller creation
# ------------------------------------------------------------

def parse_camera_arg(values: Sequence[str], width: int, height: int, fps: float) -> List[CameraController]:
    if not values:
        values = ["TOP:SIM_TOP", "BOTTOM:SIM_BOTTOM"]
    controllers: List[CameraController] = []
    for index, item in enumerate(values):
        if ":" not in item:
            raise ValueError(f"camera assignment must be ROLE:DEVICE_ID, got {item!r}")
        role, device_id = item.split(":", 1)
        controllers.append(
            SimulatedCameraController(
                role=role.strip().upper(),
                device_id=device_id.strip(),
                user_id=device_id.strip(),
                width=width,
                height=height,
                fps=fps,
                start_delay_s=0.02 * index,
            )
        )
    return controllers


def write_default_sim_config(path: str) -> None:
    config = {
        "backend": "sim",
        "cameras": [
            {"role": "TOP", "device_id": "SIM_TOP", "user_id": "TOP"},
            {"role": "BOTTOM", "device_id": "SIM_BOTTOM", "user_id": "BOTTOM"},
        ],
    }
    Path(path).write_text(json.dumps(config, indent=2), encoding="utf-8")


def write_default_ids_config(path: str) -> None:
    config = {
        "backend": "ids_peak_acquisition",
        "assignment_mode": "exact_user_id",
        "cset_path": "new3990.cset",
        "pipeline_settings_json": "pipeline_config_20260506.json",
        "image_extension": "png",
        "timeout_ms": 1000,
        "save_numpy": False,
        "cameras": [
            {"role": "TOP", "user_id": "TOP"},
            {"role": "BOTTOM", "user_id": "BOTTOM"},
        ],
        "role_keywords": {
            "TOP": ["TOP", "UPPER"],
            "BOTTOM": ["BOTTOM", "LOWER"],
        },
    }
    Path(path).write_text(json.dumps(config, indent=2), encoding="utf-8")


def write_default_dummy_ids_config(path: str) -> None:
    config = {
        "backend": "dummy_ids_peak_metadata",
        "assignment_mode": "exact_user_id",
        "cameras": [
            {"role": "TOP", "user_id": "TOP"},
            {"role": "BOTTOM", "user_id": "BOTTOM"},
        ],
        "role_keywords": {
            "TOP": ["TOP", "UPPER"],
            "BOTTOM": ["BOTTOM", "LOWER"],
        },
    }
    Path(path).write_text(json.dumps(config, indent=2), encoding="utf-8")


def load_camera_config(path: str, width: int, height: int, fps: float, dummy_camera: bool = False) -> List[CameraController]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    backend = str(data.get("backend", "sim")).lower()
    cameras = data.get("cameras", [])
    role_keywords_map = data.get("role_keywords", {}) or {}

    if dummy_camera and backend in IDS_BACKENDS:
        backend = "dummy_ids_peak_metadata"

    if backend == "sim":
        controllers: List[CameraController] = []
        for index, item in enumerate(cameras):
            controllers.append(
                SimulatedCameraController(
                    role=str(item["role"]).upper(),
                    device_id=str(item.get("device_id") or item.get("user_id") or item["role"]),
                    user_id=str(item.get("user_id") or item.get("device_id") or item["role"]),
                    width=int(item.get("width", width)),
                    height=int(item.get("height", height)),
                    fps=float(item.get("fps", fps)),
                    start_delay_s=0.02 * index,
                )
            )
        return controllers

    if backend in IDS_BACKENDS or backend in DUMMY_IDS_BACKENDS:
        use_dummy = backend in DUMMY_IDS_BACKENDS
        use_acquisition = backend in IDS_ACQUISITION_BACKENDS
        controllers = []
        items = cameras or [{"role": role} for role in DEFAULT_ROLES]

        global_cset_path = str(data.get("cset_path", ""))
        global_pipeline_json = str(data.get("pipeline_settings_json", ""))
        global_image_extension = str(data.get("image_extension", "png"))
        global_timeout_ms = int(data.get("timeout_ms", 1000))
        global_save_numpy = bool(data.get("save_numpy", False))

        for item in items:
            role = str(item["role"]).upper()
            role_keywords = item.get("role_keywords") or role_keywords_map.get(role) or [role]
            common_kwargs = dict(
                role=role,
                expected_user_id=str(item.get("user_id", "")),
                expected_serial=str(item.get("serial_number", item.get("serial", ""))),
                expected_device_id=str(item.get("device_id", "")),
                role_keywords=role_keywords,
                fps=float(item.get("fps", fps)),
            )
            if use_dummy:
                controllers.append(DummyIdsMetadataCameraController(**common_kwargs))
            elif use_acquisition:
                controllers.append(
                    IdsPeakAcquisitionCameraController(
                        **common_kwargs,
                        cset_path=str(item.get("cset_path", global_cset_path)),
                        pipeline_settings_json=str(item.get("pipeline_settings_json", global_pipeline_json)),
                        image_extension=str(item.get("image_extension", global_image_extension)),
                        timeout_ms=int(item.get("timeout_ms", global_timeout_ms)),
                        save_numpy=bool(item.get("save_numpy", global_save_numpy)),
                    )
                )
            else:
                controllers.append(IdsPeakMetadataCameraController(**common_kwargs))
        return controllers

    raise ValueError(
        f"unsupported backend {backend!r}; use sim, ids_peak_metadata, "
        f"ids_peak_acquisition, or dummy_ids_peak_metadata"
    )


def create_manager_from_args(args: argparse.Namespace) -> CameraManager:
    if args.config:
        controllers = load_camera_config(args.config, width=args.width, height=args.height, fps=args.fps, dummy_camera=args.dummy_camera)
    elif args.dummy_camera:
        controllers = load_camera_config(default_dummy_config_data_path(args), width=args.width, height=args.height, fps=args.fps)
    else:
        controllers = parse_camera_arg(args.camera, width=args.width, height=args.height, fps=args.fps)
    return CameraManager(controllers)


def default_dummy_config_data_path(args: argparse.Namespace) -> str:
    # Avoid creating temporary files when --dummy-camera is used without config.
    path = Path.cwd() / "_duo_aoi_inline_dummy_ids_config.json"
    if not path.exists():
        write_default_dummy_ids_config(str(path))
    return str(path)


# ------------------------------------------------------------
# CLI and client helpers
# ------------------------------------------------------------

def scan_ids_devices_cli(use_dummy: bool = False) -> int:
    try:
        devices = discover_dummy_ids_devices() if use_dummy else discover_ids_peak_devices()
    except Exception as exc:
        print(f"IDS discovery failed: {exc}")
        return 2
    if not devices:
        print("No IDS devices found.")
        return 1
    print(json.dumps([asdict(item) for item in devices], indent=2))
    return 0


def send_json_line(host: str, port: int, request: Dict[str, Any], timeout: float = 5.0) -> Dict[str, Any]:
    payload = (json.dumps(request) + "\n").encode("utf-8")
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall(payload)
        file = sock.makefile("rb")
        line = file.readline()
    if not line:
        raise RuntimeError("no response from camera service")
    response = json.loads(line.decode("utf-8"))
    if not isinstance(response, dict):
        raise RuntimeError(f"invalid response: {response!r}")
    return response


def run_serve(args: argparse.Namespace) -> int:
    manager = create_manager_from_args(args)
    service = CameraService(manager=manager, verbose=not args.quiet, dummy_discovery=args.dummy_camera)
    manager.start_all()

    server = ThreadedCameraServer((args.host, args.port), JsonLineHandler, service)
    print(f"DUO_AOI dual-camera service listening on {args.host}:{args.port}")
    print(f"Cameras: {manager.roles}")
    print("Assignment rule: TOP/BOTTOM controllers are bound by simulated device_id or IDS DeviceUserID/serial. ids_peak_acquisition saves real images.")
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping dual-camera service...")
    finally:
        server.shutdown()
        server.server_close()
        manager.stop_all()
    return 0


def run_ping(args: argparse.Namespace) -> int:
    response = send_json_line(args.host, args.port, {"cmd": "ping"}, timeout=args.timeout)
    print(json.dumps(response, indent=2))
    return 0 if response.get("ok") else 1


def run_status(args: argparse.Namespace) -> int:
    response = send_json_line(args.host, args.port, {"cmd": "status"}, timeout=args.timeout)
    print(json.dumps(response, indent=2))
    return 0 if response.get("ok") else 1


def run_command(args: argparse.Namespace) -> int:
    request = json.loads(args.json)
    if not isinstance(request, dict):
        raise ValueError("--json must decode to a JSON object")
    response = send_json_line(args.host, args.port, request, timeout=args.timeout)
    print(json.dumps(response, indent=2))
    return 0 if response.get("ok") else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DUO_AOI dual-camera service with real IDS acquisition and Spyder-friendly subcommands")
    sub = parser.add_subparsers(dest="mode")

    serve = sub.add_parser("serve", help="Run the JSON-lines dual-camera service")
    serve.add_argument("--host", default="127.0.0.1", help="Host/IP to bind")
    serve.add_argument("--port", type=int, default=6000, help="TCP port to bind")
    serve.add_argument("--width", type=int, default=1920, help="Simulated image width")
    serve.add_argument("--height", type=int, default=1200, help="Simulated image height")
    serve.add_argument("--fps", type=float, default=10.0, help="Simulated or metadata heartbeat FPS")
    serve.add_argument("--camera", action="append", default=[], help="Sim camera assignment ROLE:DEVICE_ID")
    serve.add_argument("--config", default="", help="Optional JSON camera config file")
    serve.add_argument("--dummy-camera", action="store_true", help="Use dummy IDS-style cameras when config requests IDS backend")
    serve.add_argument("--quiet", action="store_true", help="Reduce console output")
    serve.set_defaults(func=run_serve)

    scan = sub.add_parser("scan-ids-devices", help="Discover IDS cameras and print DeviceUserID/serial/model information")
    scan.add_argument("--dummy-camera", action="store_true", help="Use dummy IDS-style cameras instead of real IDS hardware")
    scan.set_defaults(func=lambda args: scan_ids_devices_cli(use_dummy=args.dummy_camera))

    write_sim = sub.add_parser("write-default-sim-config", help="Write a default simulated camera config")
    write_sim.add_argument("path")
    write_sim.set_defaults(func=lambda args: (write_default_sim_config(args.path), print(f"Wrote {args.path}"), 0)[2])

    write_ids = sub.add_parser("write-default-ids-config", help="Write a default IDS DeviceUserID config")
    write_ids.add_argument("path")
    write_ids.set_defaults(func=lambda args: (write_default_ids_config(args.path), print(f"Wrote {args.path}"), 0)[2])

    write_dummy = sub.add_parser("write-default-dummy-ids-config", help="Write a default dummy IDS DeviceUserID config")
    write_dummy.add_argument("path")
    write_dummy.set_defaults(func=lambda args: (write_default_dummy_ids_config(args.path), print(f"Wrote {args.path}"), 0)[2])

    ping = sub.add_parser("ping", help="Ping a running camera service")
    ping.add_argument("--host", default="127.0.0.1")
    ping.add_argument("--port", type=int, default=6000)
    ping.add_argument("--timeout", type=float, default=5.0)
    ping.set_defaults(func=run_ping)

    status = sub.add_parser("status", help="Read status from a running camera service")
    status.add_argument("--host", default="127.0.0.1")
    status.add_argument("--port", type=int, default=6000)
    status.add_argument("--timeout", type=float, default=5.0)
    status.set_defaults(func=run_status)

    command = sub.add_parser("command", help="Send an arbitrary JSON command to a running camera service")
    command.add_argument("--host", default="127.0.0.1")
    command.add_argument("--port", type=int, default=6000)
    command.add_argument("--timeout", type=float, default=5.0)
    command.add_argument("--json", required=True, help='JSON object, e.g. {"cmd":"fresh_pair"}')
    command.set_defaults(func=run_command)

    debug = sub.add_parser("debug-cameras", help="Open TOP/BOTTOM cameras, stream preview, check freshness, and save debug pairs")
    debug.add_argument("--width", type=int, default=1920, help="Simulated image width")
    debug.add_argument("--height", type=int, default=1200, help="Simulated image height")
    debug.add_argument("--fps", type=float, default=10.0, help="Simulated/metadata/debug FPS")
    debug.add_argument("--camera", action="append", default=[], help="Sim camera assignment ROLE:DEVICE_ID")
    debug.add_argument("--config", default="", help="Optional JSON camera config file")
    debug.add_argument("--dummy-camera", action="store_true", help="Use dummy IDS-style cameras when config requests IDS backend")
    debug.add_argument("--duration-s", type=float, default=10.0, help="Debug run duration in seconds; 0 means run until stopped")
    debug.add_argument("--warmup-s", type=float, default=1.0, help="Seconds to wait after opening cameras before checks/saves")
    debug.add_argument("--display", action="store_true", help="Show live TOP/BOTTOM preview window")
    debug.add_argument("--display-delay-ms", type=float, default=1.0, help="cv2.waitKey delay while display is enabled")
    debug.add_argument("--poll-s", type=float, default=0.5, help="Headless debug status print interval")
    debug.add_argument("--save-every-s", type=float, default=0.0, help="Save TOP/BOTTOM pair every N seconds; 0 disables periodic pair saves")
    debug.add_argument("--save-preview", action="store_true", help="Continuously overwrite a latest combined preview PNG")
    debug.add_argument("--output-dir", default="debug_captures", help="Debug output directory")
    debug.add_argument("--run-code", default="DEBUG_CAM", help="Run code prefix for saved debug files")
    debug.add_argument("--max-age-s", type=float, default=1.0, help="Maximum frame age for fresh check")
    debug.add_argument("--max-pair-delta-s", type=float, default=0.5, help="Maximum TOP/BOTTOM timestamp delta for fresh pair")
    debug.add_argument("--quiet", action="store_true", help="Reserved for consistency with serve mode")
    debug.set_defaults(func=run_debug_cameras)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.mode is None:
        # Terminal-friendly default: no arguments starts the service.
        args = parser.parse_args(["serve"] + list(argv or []))
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
