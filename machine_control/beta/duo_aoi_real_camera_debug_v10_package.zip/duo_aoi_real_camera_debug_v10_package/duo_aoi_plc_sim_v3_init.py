#!/usr/bin/env python3
"""
DUO_AOI PLC simulator, v3 initialization version.

This simulates an FX5U-style SLMP / MC 3E binary TCP server for the
DUO_AOI PC workflow test.

Mailbox map:
    PC -> PLC event: D100-D109
    PLC ACK:         D110-D111
    PLC diagnostics: D120-D127
    PLC -> PC event: D200-D209
    PC ACK:          D210-D211

Key behavior:
    - Explicit power-on initialization equivalent to the ST InitDone block.
    - Correct SLMP frame parsing for 3E binary read/write requests.
    - Mailbox service runs every simulated PLC scan.
    - PLC events use a pending-event queue and are published only when
      the PLC -> PC mailbox is free.
    - After PC ACK, D200-D209 are cleared and held clear for a configurable time.
    - Workflow/motion behavior is non-blocking.
"""

from __future__ import annotations

import argparse
import collections
import socketserver
import struct
import threading
import time
from dataclasses import dataclass
from typing import Deque, Iterable, List, Sequence


# ------------------------------------------------------------
# PC -> PLC events
# ------------------------------------------------------------

EVT_NONE = 0
EVT_PC_READY = 10
EVT_SET_MODE_MANUAL = 11
EVT_SET_MODE_SEMI_AUTO = 12
EVT_START_RUN = 13
EVT_STOP_RUN = 16
EVT_RESET_ERROR = 17
EVT_RECIPE_DOWNLOAD_START = 18
EVT_RECIPE_STEP_DATA = 19
EVT_RECIPE_DOWNLOAD_END = 20
EVT_CAPTURE_AUTHORIZED = 50
EVT_CAPTURE_REJECTED = 51
EVT_CAPTURE_DONE = 52


# ------------------------------------------------------------
# PLC -> PC events
# ------------------------------------------------------------

EVT_PLC_READY = 100
EVT_MODE_CHANGED = 101
EVT_RUN_STARTED = 102
EVT_RUN_STOPPED = 104
EVT_RUN_COMPLETE = 105
EVT_SEMI_STEP_STARTED = 150
EVT_POSITION_REACHED = 151
EVT_CAPTURE_AUTH_REQUEST = 152
EVT_CAPTURE_WINDOW_OPEN = 153
EVT_CAPTURE_WINDOW_CLOSED = 154
EVT_STEP_COMPLETE = 155
EVT_RECIPE_LOADED = 156
EVT_PLC_ERROR = 900

EVENT_NAMES = {
    EVT_PLC_READY: "PLC_READY",
    EVT_MODE_CHANGED: "MODE_CHANGED",
    EVT_RUN_STARTED: "RUN_STARTED",
    EVT_RUN_STOPPED: "RUN_STOPPED",
    EVT_RUN_COMPLETE: "RUN_COMPLETE",
    EVT_SEMI_STEP_STARTED: "SEMI_STEP_STARTED",
    EVT_POSITION_REACHED: "POSITION_REACHED",
    EVT_CAPTURE_AUTH_REQUEST: "CAPTURE_AUTH_REQUEST",
    EVT_CAPTURE_WINDOW_OPEN: "CAPTURE_WINDOW_OPEN",
    EVT_CAPTURE_WINDOW_CLOSED: "CAPTURE_WINDOW_CLOSED",
    EVT_STEP_COMPLETE: "STEP_COMPLETE",
    EVT_RECIPE_LOADED: "RECIPE_LOADED",
    EVT_PLC_ERROR: "PLC_ERROR",
}


# ------------------------------------------------------------
# ACK status
# ------------------------------------------------------------

ACK_OK = 0
ACK_REJECTED = 1
ACK_BUSY = 2
ACK_INVALID_STATE = 3
ACK_INVALID_PAYLOAD = 4
ACK_SAFETY_NOT_OK = 5
ACK_TIMEOUT = 6
ACK_DUPLICATE_SEQUENCE = 7
ACK_UNKNOWN_EVENT = 8

ACK_NAMES = {
    ACK_OK: "ACK_OK",
    ACK_REJECTED: "ACK_REJECTED",
    ACK_BUSY: "ACK_BUSY",
    ACK_INVALID_STATE: "ACK_INVALID_STATE",
    ACK_INVALID_PAYLOAD: "ACK_INVALID_PAYLOAD",
    ACK_SAFETY_NOT_OK: "ACK_SAFETY_NOT_OK",
    ACK_TIMEOUT: "ACK_TIMEOUT",
    ACK_DUPLICATE_SEQUENCE: "ACK_DUPLICATE_SEQUENCE",
    ACK_UNKNOWN_EVENT: "ACK_UNKNOWN_EVENT",
}


# ------------------------------------------------------------
# Register map
# ------------------------------------------------------------

D_PC_EVT = 100       # D100-D109
D_PLC_ACK = 110      # D110-D111
D_PLC_DIAG = 120     # D120-D127
D_PLC_EVT = 200      # D200-D209
D_PC_ACK = 210       # D210-D211

D_DEVICE_CODE = 0xA8


# ------------------------------------------------------------
# Simulated mode/state values
# ------------------------------------------------------------

MODE_NONE = 0
MODE_MANUAL = 1
MODE_SEMI_AUTO = 2

ST_IDLE = 20
ST_MANUAL_IDLE = 30

ST_SEMI_IDLE = 40
ST_SEMI_LOAD_STEP = 41
ST_SEMI_MOVE_START = 42
ST_SEMI_MOVE_WAIT = 43
ST_SEMI_REQUEST_CAPTURE = 44
ST_SEMI_WAIT_AUTH = 45
ST_SEMI_WAIT_CAPTURE_DONE = 46
ST_SEMI_STEP_COMPLETE = 47
ST_SEMI_RUN_COMPLETE = 48

ST_ERROR = 90

ERR_NONE = 0
ERR_PLC_INVALID_STATE = 2001
ERR_PLC_RECIPE_NOT_LOADED = 2002
ERR_PLC_UNKNOWN_EVENT = 2003
ERR_OPERATOR_CAPTURE_REJ = 8001


@dataclass(frozen=True)
class PendingEvent:
    event_type: int
    payload: List[int]


# ------------------------------------------------------------
# PLC simulation core
# ------------------------------------------------------------

class DuoAoiPlcSim:
    def __init__(
        self,
        scan_period_s: float = 0.01,
        clear_hold_s: float = 0.20,
        move_delay_s: float = 0.05,
        verbose: bool = True,
    ):
        self.scan_period_s = scan_period_s
        self.clear_hold_s = clear_hold_s
        self.move_delay_s = move_delay_s
        self.verbose = verbose

        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.scan_thread: threading.Thread | None = None

        # Simulated D register memory.
        self.d = [0] * 10000

        # Pending event queue is created before power-on initialization because
        # the init function clears it.
        self.pending_events: Deque[PendingEvent] = collections.deque()

        # These attributes are assigned in _power_on_initialize_locked().
        self.plc_state = ST_IDLE
        self.plc_mode = MODE_NONE
        self.active_error = ERR_NONE
        self.current_step = 0
        self.last_pc_seq = 0
        self.plc_seq = 0
        self.active_plc_seq = 0
        self.plc_event_active = False
        self.clear_hold_until = 0.0
        self.recipe_downloading = False
        self.recipe_loaded = False
        self.expected_recipe_steps = 0
        self.recipe_step_count = 0
        self.state_entered_at = time.monotonic()

        # Python equivalent of the PLC ST InitDone startup block.
        # It initializes internal state and PLC-owned D-register mailboxes.
        self._power_on_initialize_locked()

    # -------------------------------
    # Power-on / reset initialization
    # -------------------------------

    def _power_on_initialize_locked(self) -> None:
        """Initialize the simulator like the PLC ST InitDone block.

        The real PC still owns D100-D109 and D210-D211 at runtime, but the
        simulator starts all D memory from zero to mimic a clean power-up.
        After startup, the simulated PLC only writes PLC-owned areas:
        D110-D111, D120-D127, and D200-D209.
        """
        # Clean simulated memory at power-up.
        for i in range(len(self.d)):
            self.d[i] = 0

        # Internal state.
        self.plc_state = ST_IDLE
        self.plc_mode = MODE_NONE
        self.active_error = ERR_NONE
        self.current_step = 0

        self.last_pc_seq = 0
        self.plc_seq = 0
        self.active_plc_seq = 0
        self.plc_event_active = False
        self.clear_hold_until = 0.0

        self.recipe_downloading = False
        self.recipe_loaded = False
        self.expected_recipe_steps = 0
        self.recipe_step_count = 0

        self.pending_events.clear()
        self.state_entered_at = time.monotonic()

        # PLC-owned communication areas.
        self._clear_plc_ack_locked()
        self._clear_plc_event_mailbox_locked()
        self._refresh_diagnostics_locked()

    def _soft_reset_workflow_locked(self) -> None:
        """Reset workflow/error state without pretending the PC lost connection."""
        self.plc_state = ST_IDLE
        self.plc_mode = MODE_NONE
        self.active_error = ERR_NONE
        self.current_step = 0

        self.recipe_downloading = False
        self.recipe_loaded = False
        self.expected_recipe_steps = 0
        self.recipe_step_count = 0

        self.pending_events.clear()
        self.plc_event_active = False
        self.active_plc_seq = 0
        self.clear_hold_until = 0.0
        self.state_entered_at = time.monotonic()

        self._clear_plc_event_mailbox_locked()
        self._refresh_diagnostics_locked()

    # -------------------------------
    # Lifecycle
    # -------------------------------

    def start(self) -> None:
        self.scan_thread = threading.Thread(target=self._scan_loop, daemon=True)
        self.scan_thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.scan_thread is not None:
            self.scan_thread.join(timeout=2.0)

    # -------------------------------
    # D register access
    # -------------------------------

    def read_d(self, start: int, points: int) -> List[int]:
        with self.lock:
            self._validate_d_range(start, points)
            return [self.d[start + i] & 0xFFFF for i in range(points)]

    def write_d(self, start: int, values: Iterable[int]) -> None:
        vals = [int(v) & 0xFFFF for v in values]
        with self.lock:
            self._validate_d_range(start, len(vals))
            for i, value in enumerate(vals):
                self.d[start + i] = value

    def _validate_d_range(self, start: int, points: int) -> None:
        if start < 0 or points < 0 or start + points > len(self.d):
            raise ValueError(f"D register range out of bounds: start={start}, points={points}")

    # -------------------------------
    # PLC scan
    # -------------------------------

    def _scan_loop(self) -> None:
        next_time = time.monotonic()

        while not self.stop_event.is_set():
            with self.lock:
                self._scan_once()

            next_time += self.scan_period_s
            sleep_time = max(0.0, next_time - time.monotonic())
            time.sleep(sleep_time)

    def _scan_once(self) -> None:
        now = time.monotonic()

        # 1. Clear-hold period: keep D200-D209 visibly empty.
        if now < self.clear_hold_until:
            self._clear_plc_event_mailbox_locked()
            self._refresh_diagnostics_locked()
            return

        self.clear_hold_until = 0.0

        # 2. Service PC ACK for the active PLC event.
        if self.plc_event_active:
            pc_ack_seq = self.d[D_PC_ACK]
            pc_ack_status = self.d[D_PC_ACK + 1]

            if pc_ack_seq == self.active_plc_seq and pc_ack_status == ACK_OK:
                if self.verbose:
                    print(f"PLC SIM: PC ACK received for PLC seq={self.active_plc_seq}; clearing D200-D209")

                self._clear_plc_event_mailbox_locked()
                self.plc_event_active = False
                self.active_plc_seq = 0
                self.clear_hold_until = now + self.clear_hold_s
                self._refresh_diagnostics_locked()
                return

            # Do not process new commands or publish new events while an old PLC event is active.
            self._refresh_diagnostics_locked()
            return

        # 3. Process one new PC event if present.
        handled_pc_event = False
        pc_event_type = self.d[D_PC_EVT]
        pc_seq = self.d[D_PC_EVT + 1]
        if pc_event_type != EVT_NONE and pc_seq != 0 and pc_seq != self.last_pc_seq:
            self._handle_pc_event_locked()
            handled_pc_event = True

        # 4. Advance one small workflow step only if no PC event was handled.
        if not handled_pc_event:
            self._advance_workflow_locked(now)

        # 5. Publish at most one pending PLC event when mailbox is free.
        self._publish_next_pending_event_locked()

        # 6. Always refresh diagnostics/status.
        self._refresh_diagnostics_locked()

    # -------------------------------
    # State helper
    # -------------------------------

    def _set_state_locked(self, new_state: int) -> None:
        if self.plc_state != new_state:
            self.plc_state = new_state
            self.state_entered_at = time.monotonic()

    # -------------------------------
    # Mailbox helpers
    # -------------------------------

    def _clear_plc_ack_locked(self) -> None:
        self.d[D_PLC_ACK] = 0
        self.d[D_PLC_ACK + 1] = 0

    def _clear_plc_event_mailbox_locked(self) -> None:
        for i in range(10):
            self.d[D_PLC_EVT + i] = 0

    def _queue_plc_event_locked(self, event_type: int, payload: Sequence[int] | None = None) -> None:
        pay = list(payload or [])[:8]
        pay += [0] * (8 - len(pay))
        self.pending_events.append(PendingEvent(event_type, pay))

        if self.verbose:
            name = EVENT_NAMES.get(event_type, f"EVENT_{event_type}")
            print(f"PLC SIM queue: {name} ({event_type}) payload={pay}")

    def _publish_next_pending_event_locked(self) -> None:
        if self.plc_event_active or not self.pending_events:
            return

        pending = self.pending_events.popleft()

        self.plc_seq = (self.plc_seq + 1) & 0xFFFF
        if self.plc_seq == 0:
            self.plc_seq = 1

        self.active_plc_seq = self.plc_seq
        self.d[D_PLC_EVT] = pending.event_type & 0xFFFF
        self.d[D_PLC_EVT + 1] = self.active_plc_seq & 0xFFFF

        for i, value in enumerate(pending.payload):
            self.d[D_PLC_EVT + 2 + i] = int(value) & 0xFFFF

        self.plc_event_active = True

        if self.verbose:
            name = EVENT_NAMES.get(pending.event_type, f"EVENT_{pending.event_type}")
            print(
                f"PLC SIM -> PC: {name} ({pending.event_type}) "
                f"seq={self.active_plc_seq} payload={pending.payload}"
            )

    def _ack_pc_event_locked(self, pc_seq: int, status: int = ACK_OK) -> None:
        self.d[D_PLC_ACK] = pc_seq & 0xFFFF
        self.d[D_PLC_ACK + 1] = status & 0xFFFF

        if self.verbose:
            ack_name = ACK_NAMES.get(status, f"ACK_{status}")
            print(f"PLC SIM ACK -> PC: seq={pc_seq} status={status} ({ack_name})")

    # -------------------------------
    # PC event handling
    # -------------------------------

    def _handle_pc_event_locked(self) -> None:
        pc_event_type = self.d[D_PC_EVT]
        pc_seq = self.d[D_PC_EVT + 1]
        payload = [self.d[D_PC_EVT + 2 + i] for i in range(8)]

        if self.verbose:
            print(f"PLC SIM: PC event={pc_event_type} seq={pc_seq} payload={payload}")

        ack_status = ACK_OK

        if pc_event_type == EVT_PC_READY:
            self._soft_reset_workflow_locked()
            self._queue_plc_event_locked(EVT_PLC_READY, [self.plc_state])

        elif pc_event_type == EVT_SET_MODE_MANUAL:
            self.plc_mode = MODE_MANUAL
            self._set_state_locked(ST_MANUAL_IDLE)
            self.active_error = ERR_NONE
            self._queue_plc_event_locked(EVT_MODE_CHANGED, [self.plc_mode, self.plc_state])

        elif pc_event_type == EVT_SET_MODE_SEMI_AUTO:
            self.plc_mode = MODE_SEMI_AUTO
            self._set_state_locked(ST_SEMI_IDLE)
            self.active_error = ERR_NONE
            self._queue_plc_event_locked(EVT_MODE_CHANGED, [self.plc_mode, self.plc_state])

        elif pc_event_type == EVT_RECIPE_DOWNLOAD_START:
            self.recipe_downloading = True
            self.recipe_loaded = False
            self.expected_recipe_steps = payload[0]
            self.recipe_step_count = 0
            self.current_step = 0
            self._set_state_locked(ST_SEMI_IDLE)
            self.active_error = ERR_NONE

        elif pc_event_type == EVT_RECIPE_STEP_DATA:
            if self.recipe_downloading:
                self.recipe_step_count += 1
                self.active_error = ERR_NONE
            else:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_INVALID_STATE

        elif pc_event_type == EVT_RECIPE_DOWNLOAD_END:
            if self.recipe_downloading:
                self.recipe_downloading = False
                self.recipe_loaded = True
                self._set_state_locked(ST_SEMI_IDLE)
                self.active_error = ERR_NONE
                self._queue_plc_event_locked(
                    EVT_RECIPE_LOADED,
                    [self.expected_recipe_steps, self.recipe_step_count],
                )
            else:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_INVALID_STATE

        elif pc_event_type == EVT_START_RUN:
            if self.plc_mode != MODE_SEMI_AUTO:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_INVALID_STATE

            elif not self.recipe_loaded:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_RECIPE_NOT_LOADED

            else:
                self.current_step = 0
                self._set_state_locked(ST_SEMI_LOAD_STEP)
                self.active_error = ERR_NONE
                self._queue_plc_event_locked(
                    EVT_RUN_STARTED,
                    [self.recipe_step_count, self.plc_state],
                )

        elif pc_event_type == EVT_CAPTURE_AUTHORIZED:
            if self.plc_state == ST_SEMI_WAIT_AUTH:
                self._set_state_locked(ST_SEMI_WAIT_CAPTURE_DONE)
                self.active_error = ERR_NONE
                self._queue_plc_event_locked(
                    EVT_CAPTURE_WINDOW_OPEN,
                    [self.current_step, self.plc_state],
                )
            else:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_INVALID_STATE

        elif pc_event_type == EVT_CAPTURE_REJECTED:
            self.active_error = ERR_OPERATOR_CAPTURE_REJ
            self._set_state_locked(ST_ERROR)
            self._queue_plc_event_locked(
                EVT_PLC_ERROR,
                [self.active_error, self.current_step],
            )

        elif pc_event_type == EVT_CAPTURE_DONE:
            if self.plc_state == ST_SEMI_WAIT_CAPTURE_DONE:
                self._set_state_locked(ST_SEMI_STEP_COMPLETE)
                self.active_error = ERR_NONE
                self._queue_plc_event_locked(
                    EVT_CAPTURE_WINDOW_CLOSED,
                    [self.current_step, self.plc_state],
                )
            else:
                ack_status = ACK_INVALID_STATE
                self.active_error = ERR_PLC_INVALID_STATE

        elif pc_event_type == EVT_STOP_RUN:
            self._set_state_locked(ST_IDLE)
            self.current_step = 0
            self.active_error = ERR_NONE
            self.pending_events.clear()
            self._queue_plc_event_locked(EVT_RUN_STOPPED, [self.plc_state])

        elif pc_event_type == EVT_RESET_ERROR:
            self._soft_reset_workflow_locked()

        else:
            ack_status = ACK_UNKNOWN_EVENT
            self.active_error = ERR_PLC_UNKNOWN_EVENT

        self._ack_pc_event_locked(pc_seq, ack_status)
        self.last_pc_seq = pc_seq

    # -------------------------------
    # Workflow sequencer
    # -------------------------------

    def _advance_workflow_locked(self, now: float) -> None:
        if self.plc_state == ST_SEMI_LOAD_STEP:
            if self.current_step < self.recipe_step_count:
                self._queue_plc_event_locked(
                    EVT_SEMI_STEP_STARTED,
                    [self.current_step, self.plc_state],
                )
                self._set_state_locked(ST_SEMI_MOVE_START)
            else:
                self._set_state_locked(ST_SEMI_RUN_COMPLETE)

        elif self.plc_state == ST_SEMI_MOVE_START:
            # Non-blocking motion start. A real PLC would pulse the motion command here.
            self._set_state_locked(ST_SEMI_MOVE_WAIT)

        elif self.plc_state == ST_SEMI_MOVE_WAIT:
            # Non-blocking motion wait. The simulated move completes after move_delay_s.
            if now - self.state_entered_at >= self.move_delay_s:
                self._queue_plc_event_locked(
                    EVT_POSITION_REACHED,
                    [self.current_step, self.plc_state],
                )
                self._set_state_locked(ST_SEMI_REQUEST_CAPTURE)

        elif self.plc_state == ST_SEMI_REQUEST_CAPTURE:
            self._queue_plc_event_locked(
                EVT_CAPTURE_AUTH_REQUEST,
                [self.current_step, self.plc_state],
            )
            self._set_state_locked(ST_SEMI_WAIT_AUTH)

        elif self.plc_state == ST_SEMI_STEP_COMPLETE:
            self._queue_plc_event_locked(
                EVT_STEP_COMPLETE,
                [self.current_step, self.plc_state],
            )

            self.current_step += 1
            if self.current_step >= self.recipe_step_count:
                self._set_state_locked(ST_SEMI_RUN_COMPLETE)
            else:
                self._set_state_locked(ST_SEMI_LOAD_STEP)

        elif self.plc_state == ST_SEMI_RUN_COMPLETE:
            self._queue_plc_event_locked(
                EVT_RUN_COMPLETE,
                [self.recipe_step_count, self.plc_state],
            )
            self._set_state_locked(ST_SEMI_IDLE)

    # -------------------------------
    # Diagnostics
    # -------------------------------

    def _refresh_diagnostics_locked(self) -> None:
        self.d[D_PLC_DIAG] = self.active_error & 0xFFFF          # D120
        self.d[D_PLC_DIAG + 1] = len(self.pending_events) & 0xFFFF  # D121 pending events
        self.d[D_PLC_DIAG + 2] = 1 if self.plc_event_active else 0  # D122 event active
        self.d[D_PLC_DIAG + 3] = self.d[D_PC_EVT] & 0xFFFF       # D123 last/current PC event
        self.d[D_PLC_DIAG + 4] = self.d[D_PC_EVT + 1] & 0xFFFF   # D124 last/current PC seq
        self.d[D_PLC_DIAG + 5] = self.plc_state & 0xFFFF         # D125 PLC state
        self.d[D_PLC_DIAG + 6] = self.plc_mode & 0xFFFF          # D126 PLC mode
        self.d[D_PLC_DIAG + 7] = self.current_step & 0xFFFF      # D127 current step


# ------------------------------------------------------------
# SLMP / MC 3E binary TCP server
# ------------------------------------------------------------

class SlmpRequestHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        sim: DuoAoiPlcSim = self.server.sim  # type: ignore[attr-defined]
        buffer = b""

        while True:
            chunk = self.request.recv(4096)
            if not chunk:
                return

            buffer += chunk

            while True:
                if len(buffer) < 9:
                    break

                if buffer[0:2] != b"\x50\x00":
                    print(f"PLC SIM: invalid request subheader: {buffer[:2].hex(' ')}")
                    return

                request_length = struct.unpack("<H", buffer[7:9])[0]
                frame_length = 9 + request_length

                if len(buffer) < frame_length:
                    break

                frame = buffer[:frame_length]
                buffer = buffer[frame_length:]

                response = self._handle_frame(sim, frame)
                self.request.sendall(response)

    def _handle_frame(self, sim: DuoAoiPlcSim, frame: bytes) -> bytes:
        request_data = frame[9:]
        if len(request_data) < 2:
            return self._build_response(frame, end_code=0xC051)

        # request_data starts with a 2-byte monitoring timer.
        payload = request_data[2:]

        # command(2), subcommand(2), device_no(3), device_code(1), points(2)
        if len(payload) < 10:
            return self._build_response(frame, end_code=0xC051)

        command = struct.unpack("<H", payload[0:2])[0]
        subcommand = struct.unpack("<H", payload[2:4])[0]
        start = int.from_bytes(payload[4:7], byteorder="little", signed=False)
        device_code = payload[7]
        points = struct.unpack("<H", payload[8:10])[0]

        if subcommand != 0x0000 or device_code != D_DEVICE_CODE:
            return self._build_response(frame, end_code=0xC059)

        try:
            # Batch read.
            if command == 0x0401:
                values = sim.read_d(start, points)
                data = struct.pack("<" + "H" * points, *values)
                return self._build_response(frame, data=data)

            # Batch write.
            if command == 0x1401:
                raw_values = payload[10:]
                needed = points * 2

                if len(raw_values) < needed:
                    return self._build_response(frame, end_code=0xC051)

                values = list(struct.unpack("<" + "H" * points, raw_values[:needed]))
                sim.write_d(start, values)
                return self._build_response(frame)

        except ValueError:
            return self._build_response(frame, end_code=0xC051)

        return self._build_response(frame, end_code=0xC059)

    def _build_response(self, request_frame: bytes, data: bytes = b"", end_code: int = 0) -> bytes:
        # 3E binary response header:
        # subheader D0 00, then network/pc/io/station copied from request.
        subheader = b"\xD0\x00"
        network_to_station = request_frame[2:7]
        response_body = struct.pack("<H", end_code) + data
        response_length = struct.pack("<H", len(response_body))
        return subheader + network_to_station + response_length + response_body


class ThreadedSlmpServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, server_address, handler_class, sim: DuoAoiPlcSim):
        super().__init__(server_address, handler_class)
        self.sim = sim


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="DUO_AOI PLC simulator v3 init version using SLMP/MC 3E binary TCP")
    parser.add_argument("--host", default="127.0.0.1", help="Host/IP to bind")
    parser.add_argument("--port", type=int, default=5000, help="TCP port to bind")
    parser.add_argument("--scan-ms", type=float, default=10.0, help="Simulated PLC scan period in ms")
    parser.add_argument("--clear-hold-ms", type=float, default=200.0, help="Hold D200-D209 clear after PC ACK")
    parser.add_argument("--move-ms", type=float, default=50.0, help="Simulated non-blocking move duration in ms")
    parser.add_argument("--quiet", action="store_true", help="Reduce console output")
    args = parser.parse_args()

    sim = DuoAoiPlcSim(
        scan_period_s=args.scan_ms / 1000.0,
        clear_hold_s=args.clear_hold_ms / 1000.0,
        move_delay_s=args.move_ms / 1000.0,
        verbose=not args.quiet,
    )
    sim.start()

    server = ThreadedSlmpServer((args.host, args.port), SlmpRequestHandler, sim)

    print(f"DUO_AOI PLC SIM v3-init listening on {args.host}:{args.port}")
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping PLC SIM...")
    finally:
        server.shutdown()
        server.server_close()
        sim.stop()


if __name__ == "__main__":
    main()
