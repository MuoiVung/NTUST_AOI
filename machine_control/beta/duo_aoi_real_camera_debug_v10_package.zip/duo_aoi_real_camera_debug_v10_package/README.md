# DUO AOI dual-camera service v10 debug package

This package adds a standalone `debug-cameras` mode to the dual-camera service.

The same service supports:

- `scan-ids-devices`: scan IDS devices and print `DeviceUserID`, serial, model, and resolution.
- `debug-cameras`: scan, open TOP/BOTTOM controllers, stream a two-panel debug preview, check freshness, and save paired debug captures.
- `serve`: run the JSON-lines camera service used by the PC/PLC workflow.
- `ping`, `status`, and `command`: simple client utilities for a running service.

The CLI uses positional modes so it works cleanly in Spyder `%runfile --args "..."`.

## 1. Scan dummy cameras

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "scan-ids-devices --dummy-camera"
```

## 2. Scan real IDS cameras

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "scan-ids-devices"
```

Expected real camera assignment:

```text
DeviceUserID = TOP     -> TOP controller
DeviceUserID = BOTTOM  -> BOTTOM controller
```

## 3. Run dummy debug-camera mode

Headless debug test:

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "debug-cameras --dummy-camera --duration-s 5 --save-every-s 1 --save-preview --output-dir debug_captures --run-code DUMMY_DEBUG"
```

With OpenCV display preview:

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "debug-cameras --dummy-camera --duration-s 20 --display --save-every-s 2 --output-dir debug_captures --run-code DUMMY_DEBUG"
```

## 4. Run real IDS debug-camera mode

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "debug-cameras --config camera_config_real_ids_acquisition.json --duration-s 20 --display --save-every-s 2 --save-preview --output-dir real_debug_captures --run-code REAL_DEBUG"
```

This opens the cameras by `DeviceUserID`, starts acquisition, displays TOP/BOTTOM frames, and saves paired images/manifests periodically.

## 5. Run camera service for PC/PLC workflow

Dummy IDS service:

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "serve --host 127.0.0.1 --port 6000 --config camera_config_dummy_ids_userid.json"
```

Real IDS acquisition service:

```python
%runfile C:/Users/user/Documents/gcodefiles/duo_aoi_real_camera_debug_v10_package/duo_aoi_camera_pair_service_v10_debug.py --args "serve --host 127.0.0.1 --port 6000 --config camera_config_real_ids_acquisition.json"
```

## 6. Full simulated PLC + camera workflow test

Terminal 1:

```bash
python duo_aoi_plc_sim_v3_init.py --host 127.0.0.1 --port 5000
```

Terminal 2:

```bash
python duo_aoi_camera_pair_service_v10_debug.py serve --host 127.0.0.1 --port 6000 --config camera_config_dummy_ids_userid.json
```

Terminal 3:

```bash
python duo_aoi_pc_workflow_dual_camera_test.py --host 127.0.0.1 --port 5000 --camera-host 127.0.0.1 --camera-port 6000 --steps 5 --run-code DEBUGFULL --image-output-dir captures
```

## Notes

- The real IDS acquisition backend follows the actual IDS Peak acquisition pattern: IDS initialization, camera discovery, `DeviceUserID` pairing, optional `.cset` loading, software trigger setup, `DefaultPipeline` processing, latest-frame storage, and image saving.
- `debug-cameras` does not require the PLC.
- The PC/PLC workflow still uses `serve` mode.
